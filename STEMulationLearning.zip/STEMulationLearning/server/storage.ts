import {
  users,
  jobPostings,
  videoPortfolios,
  employerGroups,
  groupMembers,
  trainingModules,
  trainingProgress,
  jobApplications,
  memberConnections,
  jobAlerts,
  messages,
  notifications,
  userReviews,
  userAnalytics,
  savedJobs,
  videoLikes,
  videoComments,
  type User,
  type UpsertUser,
  type JobPosting,
  type InsertJobPosting,
  type VideoPortfolio,
  type InsertVideoPortfolio,
  type EmployerGroup,
  type InsertEmployerGroup,
  type TrainingModule,
  type InsertTrainingModule,
  type JobApplication,
  type InsertJobApplication,
  type MemberConnection,
  type InsertMemberConnection,
  type JobAlert,
  type InsertJobAlert,
  type Message,
  type InsertMessage,
  type Notification,
  type InsertNotification,
  type UserReview,
  type InsertUserReview,
  type TrainingProgress,
  type UserAnalytics,
  type SavedJob,
  type VideoLike,
  type VideoComment,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, and, or, like, count, sql, inArray } from "drizzle-orm";

// Enhanced storage interface with all new features
export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserProfiles(id: string, profiles: { linkedinProfileUrl?: string; indeedProfileUrl?: string }): Promise<User>;
  updateUserYouTubeTokens(id: string, tokens: { accessToken: string; refreshToken?: string; channelId?: string }): Promise<User>;
  updateUserProfile(id: string, updates: Partial<User>): Promise<User>;
  updateUserRating(id: string, newRating: number): Promise<User>;
  getUsersByLocation(location: string): Promise<User[]>;
  getUsersByTradeSpecialty(specialty: string): Promise<User[]>;
  
  // Job posting operations
  getAllJobPostings(limit?: number, offset?: number): Promise<JobPosting[]>;
  getJobPosting(id: number): Promise<JobPosting | undefined>;
  createJobPosting(jobPosting: InsertJobPosting): Promise<JobPosting>;
  updateJobPosting(id: number, updates: Partial<InsertJobPosting>): Promise<JobPosting>;
  deleteJobPosting(id: number): Promise<void>;
  getJobPostingsByCategory(category: string, limit?: number, offset?: number): Promise<JobPosting[]>;
  getJobPostingsByUserId(userId: string): Promise<JobPosting[]>;
  searchJobPostings(query: {
    keywords?: string[];
    location?: string;
    tradeCategory?: string;
    salaryMin?: number;
    salaryMax?: number;
    experienceLevel?: string;
    employmentType?: string;
  }, limit?: number, offset?: number): Promise<JobPosting[]>;
  getFeaturedJobPostings(limit?: number): Promise<JobPosting[]>;
  incrementJobViewCount(id: number): Promise<void>;
  
  // Video portfolio operations
  getAllVideoPortfolios(limit?: number, offset?: number): Promise<VideoPortfolio[]>;
  getVideoPortfolio(id: number): Promise<VideoPortfolio | undefined>;
  createVideoPortfolio(portfolio: InsertVideoPortfolio): Promise<VideoPortfolio>;
  updateVideoPortfolio(id: number, updates: Partial<InsertVideoPortfolio>): Promise<VideoPortfolio>;
  deleteVideoPortfolio(id: number): Promise<void>;
  getVideoPortfoliosByCategory(category: string, limit?: number, offset?: number): Promise<VideoPortfolio[]>;
  getVideoPortfoliosByUserId(userId: string): Promise<VideoPortfolio[]>;
  incrementVideoViewCount(id: number): Promise<void>;
  
  // Employer group operations
  getEmployerGroupsByUserId(userId: string): Promise<EmployerGroup[]>;
  createEmployerGroup(group: InsertEmployerGroup): Promise<EmployerGroup>;
  getEmployerGroup(id: number): Promise<EmployerGroup | undefined>;
  deleteEmployerGroup(id: number): Promise<void>;
  
  // Training module operations
  getTrainingModulesByGroupId(groupId: number): Promise<TrainingModule[]>;
  createTrainingModule(module: InsertTrainingModule): Promise<TrainingModule>;
  getTrainingModule(id: number): Promise<TrainingModule | undefined>;
  deleteTrainingModule(id: number): Promise<void>;
  
  // Training progress operations
  getUserTrainingProgress(userId: string, moduleId?: number): Promise<TrainingProgress[]>;
  updateTrainingProgress(userId: string, moduleId: number, progress: Partial<TrainingProgress>): Promise<TrainingProgress>;
  
  // Job application operations
  createJobApplication(application: InsertJobApplication): Promise<JobApplication>;
  getJobApplicationsByUserId(userId: string): Promise<JobApplication[]>;
  getJobApplicationsByJobId(jobId: number): Promise<JobApplication[]>;
  updateJobApplicationStatus(id: number, status: string, notes?: string): Promise<JobApplication>;
  
  // Member connection operations
  createMemberConnection(connection: InsertMemberConnection): Promise<MemberConnection>;
  getMemberConnectionsByUserId(userId: string): Promise<MemberConnection[]>;
  updateMemberConnectionStatus(id: number, status: string): Promise<void>;
  
  // Job alert operations
  createJobAlert(alert: InsertJobAlert): Promise<JobAlert>;
  getJobAlertsByUserId(userId: string): Promise<JobAlert[]>;
  deleteJobAlert(id: number): Promise<void>;
  
  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesByUserId(userId: string, limit?: number, offset?: number): Promise<Message[]>;
  getConversation(userId1: string, userId2: string): Promise<Message[]>;
  markMessageAsRead(messageId: number): Promise<void>;
  getUnreadMessageCount(userId: string): Promise<number>;
  
  // Notification operations
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotificationsByUserId(userId: string, limit?: number): Promise<Notification[]>;
  markNotificationAsRead(notificationId: number): Promise<void>;
  getUnreadNotificationCount(userId: string): Promise<number>;
  
  // Review operations
  createUserReview(review: InsertUserReview): Promise<UserReview>;
  getUserReviews(userId: string): Promise<UserReview[]>;
  
  // Analytics operations
  logUserAction(userId: string, actionType: string, resourceType?: string, resourceId?: string, metadata?: any): Promise<void>;
  getUserAnalytics(userId: string, actionType?: string): Promise<UserAnalytics[]>;
  
  // Video interaction operations
  likeVideo(userId: string, videoId: number): Promise<VideoLike>;
  unlikeVideo(userId: string, videoId: number): Promise<void>;
  isVideoLiked(userId: string, videoId: number): Promise<boolean>;
  addVideoComment(videoId: number, userId: string, comment: string, parentCommentId?: number): Promise<VideoComment>;
  getVideoComments(videoId: number): Promise<VideoComment[]>;
  
  // Saved jobs operations
  saveJob(userId: string, jobId: number, notes?: string): Promise<SavedJob>;
  unsaveJob(userId: string, jobId: number): Promise<void>;
  getSavedJobs(userId: string): Promise<SavedJob[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserProfiles(id: string, profiles: { linkedinProfileUrl?: string; indeedProfileUrl?: string }): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        ...profiles,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserYouTubeTokens(id: string, tokens: { accessToken: string; refreshToken?: string; channelId?: string }): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        youtubeAccessToken: tokens.accessToken,
        youtubeRefreshToken: tokens.refreshToken,
        youtubeChannelId: tokens.channelId,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserProfile(id: string, updates: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserRating(id: string, newRating: number): Promise<User> {
    const [currentUser] = await db.select().from(users).where(eq(users.id, id));
    if (!currentUser) throw new Error('User not found');

    const currentRating = parseFloat(currentUser.rating || '0');
    const totalRatings = currentUser.totalRatings || 0;
    const updatedRating = ((currentRating * totalRatings) + newRating) / (totalRatings + 1);

    const [user] = await db
      .update(users)
      .set({
        rating: updatedRating.toFixed(2),
        totalRatings: totalRatings + 1,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getUsersByLocation(location: string): Promise<User[]> {
    return await db.select().from(users).where(like(users.location, `%${location}%`));
  }

  async getUsersByTradeSpecialty(specialty: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.tradeSpecialty, specialty));
  }

  // Job posting operations
  async getAllJobPostings(limit = 50, offset = 0): Promise<JobPosting[]> {
    return await db
      .select()
      .from(jobPostings)
      .where(eq(jobPostings.isActive, true))
      .orderBy(desc(jobPostings.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getJobPosting(id: number): Promise<JobPosting | undefined> {
    const [jobPosting] = await db.select().from(jobPostings).where(eq(jobPostings.id, id));
    return jobPosting;
  }

  async createJobPosting(jobPosting: InsertJobPosting): Promise<JobPosting> {
    const [newJobPosting] = await db
      .insert(jobPostings)
      .values(jobPosting)
      .returning();
    return newJobPosting;
  }

  async updateJobPosting(id: number, updates: Partial<InsertJobPosting>): Promise<JobPosting> {
    const [jobPosting] = await db
      .update(jobPostings)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(jobPostings.id, id))
      .returning();
    return jobPosting;
  }

  async deleteJobPosting(id: number): Promise<void> {
    await db.delete(jobPostings).where(eq(jobPostings.id, id));
  }

  async getJobPostingsByCategory(category: string, limit = 50, offset = 0): Promise<JobPosting[]> {
    return await db
      .select()
      .from(jobPostings)
      .where(and(eq(jobPostings.tradeCategory, category), eq(jobPostings.isActive, true)))
      .orderBy(desc(jobPostings.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getJobPostingsByUserId(userId: string): Promise<JobPosting[]> {
    return await db
      .select()
      .from(jobPostings)
      .where(eq(jobPostings.postedBy, userId))
      .orderBy(desc(jobPostings.createdAt));
  }

  async searchJobPostings(query: {
    keywords?: string[];
    location?: string;
    tradeCategory?: string;
    salaryMin?: number;
    salaryMax?: number;
    experienceLevel?: string;
    employmentType?: string;
  }, limit = 50, offset = 0): Promise<JobPosting[]> {
    let conditions = [eq(jobPostings.isActive, true)];

    if (query.keywords?.length) {
      const keywordConditions = query.keywords.map(keyword => 
        or(
          like(jobPostings.title, `%${keyword}%`),
          like(jobPostings.description, `%${keyword}%`),
          like(jobPostings.requirements, `%${keyword}%`)
        )
      );
      conditions.push(or(...keywordConditions));
    }

    if (query.location) {
      conditions.push(like(jobPostings.location, `%${query.location}%`));
    }

    if (query.tradeCategory) {
      conditions.push(eq(jobPostings.tradeCategory, query.tradeCategory));
    }

    if (query.salaryMin && jobPostings.salaryMin) {
      conditions.push(sql`${jobPostings.salaryMin} >= ${query.salaryMin}`);
    }

    if (query.experienceLevel) {
      conditions.push(eq(jobPostings.experienceLevel, query.experienceLevel));
    }

    if (query.employmentType) {
      conditions.push(eq(jobPostings.employmentType, query.employmentType));
    }

    return await db
      .select()
      .from(jobPostings)
      .where(and(...conditions))
      .orderBy(desc(jobPostings.priority), desc(jobPostings.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getFeaturedJobPostings(limit = 10): Promise<JobPosting[]> {
    return await db
      .select()
      .from(jobPostings)
      .where(and(eq(jobPostings.isActive, true), sql`${jobPostings.priority} > 0`))
      .orderBy(desc(jobPostings.priority), desc(jobPostings.createdAt))
      .limit(limit);
  }

  async incrementJobViewCount(id: number): Promise<void> {
    await db
      .update(jobPostings)
      .set({
        viewCount: sql`${jobPostings.viewCount} + 1`,
      })
      .where(eq(jobPostings.id, id));
  }

  // Video portfolio operations
  async getAllVideoPortfolios(limit = 50, offset = 0): Promise<VideoPortfolio[]> {
    return await db
      .select()
      .from(videoPortfolios)
      .where(eq(videoPortfolios.isPublic, true))
      .orderBy(desc(videoPortfolios.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getVideoPortfolio(id: number): Promise<VideoPortfolio | undefined> {
    const [video] = await db.select().from(videoPortfolios).where(eq(videoPortfolios.id, id));
    return video;
  }

  async createVideoPortfolio(portfolio: InsertVideoPortfolio): Promise<VideoPortfolio> {
    const [newVideo] = await db
      .insert(videoPortfolios)
      .values(portfolio)
      .returning();
    return newVideo;
  }

  async updateVideoPortfolio(id: number, updates: Partial<InsertVideoPortfolio>): Promise<VideoPortfolio> {
    const [video] = await db
      .update(videoPortfolios)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(videoPortfolios.id, id))
      .returning();
    return video;
  }

  async deleteVideoPortfolio(id: number): Promise<void> {
    await db.delete(videoPortfolios).where(eq(videoPortfolios.id, id));
  }

  async getVideoPortfoliosByCategory(category: string, limit = 50, offset = 0): Promise<VideoPortfolio[]> {
    return await db
      .select()
      .from(videoPortfolios)
      .where(and(eq(videoPortfolios.tradeCategory, category), eq(videoPortfolios.isPublic, true)))
      .orderBy(desc(videoPortfolios.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getVideoPortfoliosByUserId(userId: string): Promise<VideoPortfolio[]> {
    return await db
      .select()
      .from(videoPortfolios)
      .where(eq(videoPortfolios.userId, userId))
      .orderBy(desc(videoPortfolios.createdAt));
  }

  async incrementVideoViewCount(id: number): Promise<void> {
    await db
      .update(videoPortfolios)
      .set({
        viewCount: sql`${videoPortfolios.viewCount} + 1`,
      })
      .where(eq(videoPortfolios.id, id));
  }

  // Employer group operations
  async getEmployerGroupsByUserId(userId: string): Promise<EmployerGroup[]> {
    return await db
      .select()
      .from(employerGroups)
      .where(eq(employerGroups.employerId, userId))
      .orderBy(desc(employerGroups.createdAt));
  }

  async createEmployerGroup(group: InsertEmployerGroup): Promise<EmployerGroup> {
    const [newGroup] = await db
      .insert(employerGroups)
      .values(group)
      .returning();
    return newGroup;
  }

  async getEmployerGroup(id: number): Promise<EmployerGroup | undefined> {
    const [group] = await db.select().from(employerGroups).where(eq(employerGroups.id, id));
    return group;
  }

  async deleteEmployerGroup(id: number): Promise<void> {
    await db.delete(employerGroups).where(eq(employerGroups.id, id));
  }

  // Training module operations
  async getTrainingModulesByGroupId(groupId: number): Promise<TrainingModule[]> {
    return await db
      .select()
      .from(trainingModules)
      .where(and(eq(trainingModules.groupId, groupId), eq(trainingModules.isActive, true)))
      .orderBy(asc(trainingModules.createdAt));
  }

  async createTrainingModule(module: InsertTrainingModule): Promise<TrainingModule> {
    const [newModule] = await db
      .insert(trainingModules)
      .values(module)
      .returning();
    return newModule;
  }

  async getTrainingModule(id: number): Promise<TrainingModule | undefined> {
    const [module] = await db.select().from(trainingModules).where(eq(trainingModules.id, id));
    return module;
  }

  async deleteTrainingModule(id: number): Promise<void> {
    await db.delete(trainingModules).where(eq(trainingModules.id, id));
  }

  // Training progress operations
  async getUserTrainingProgress(userId: string, moduleId?: number): Promise<TrainingProgress[]> {
    let query = db.select().from(trainingProgress).where(eq(trainingProgress.userId, userId));
    
    if (moduleId) {
      query = query.where(eq(trainingProgress.moduleId, moduleId));
    }
    
    return await query.orderBy(desc(trainingProgress.updatedAt));
  }

  async updateTrainingProgress(userId: string, moduleId: number, progress: Partial<TrainingProgress>): Promise<TrainingProgress> {
    const [existingProgress] = await db
      .select()
      .from(trainingProgress)
      .where(and(eq(trainingProgress.userId, userId), eq(trainingProgress.moduleId, moduleId)));

    if (existingProgress) {
      const [updatedProgress] = await db
        .update(trainingProgress)
        .set({
          ...progress,
          updatedAt: new Date(),
        })
        .where(and(eq(trainingProgress.userId, userId), eq(trainingProgress.moduleId, moduleId)))
        .returning();
      return updatedProgress;
    } else {
      const [newProgress] = await db
        .insert(trainingProgress)
        .values({
          userId,
          moduleId,
          ...progress,
        })
        .returning();
      return newProgress;
    }
  }

  // Job application operations
  async createJobApplication(application: InsertJobApplication): Promise<JobApplication> {
    const [newApplication] = await db
      .insert(jobApplications)
      .values(application)
      .returning();

    // Update application count for job posting
    await db
      .update(jobPostings)
      .set({
        applicationCount: sql`${jobPostings.applicationCount} + 1`,
      })
      .where(eq(jobPostings.id, application.jobId));

    return newApplication;
  }

  async getJobApplicationsByUserId(userId: string): Promise<JobApplication[]> {
    return await db
      .select()
      .from(jobApplications)
      .where(eq(jobApplications.applicantId, userId))
      .orderBy(desc(jobApplications.appliedAt));
  }

  async getJobApplicationsByJobId(jobId: number): Promise<JobApplication[]> {
    return await db
      .select()
      .from(jobApplications)
      .where(eq(jobApplications.jobId, jobId))
      .orderBy(desc(jobApplications.appliedAt));
  }

  async updateJobApplicationStatus(id: number, status: string, notes?: string): Promise<JobApplication> {
    const updateData: any = { status, updatedAt: new Date() };
    if (notes) updateData.notes = notes;

    const [application] = await db
      .update(jobApplications)
      .set(updateData)
      .where(eq(jobApplications.id, id))
      .returning();
    return application;
  }

  // Member connection operations
  async createMemberConnection(connection: InsertMemberConnection): Promise<MemberConnection> {
    const [newConnection] = await db
      .insert(memberConnections)
      .values(connection)
      .returning();
    return newConnection;
  }

  async getMemberConnectionsByUserId(userId: string): Promise<MemberConnection[]> {
    return await db
      .select()
      .from(memberConnections)
      .where(or(eq(memberConnections.requesterId, userId), eq(memberConnections.receiverId, userId)))
      .orderBy(desc(memberConnections.createdAt));
  }

  async updateMemberConnectionStatus(id: number, status: string): Promise<void> {
    const updateData: any = { status };
    if (status === 'accepted') {
      updateData.connectedAt = new Date();
    }

    await db
      .update(memberConnections)
      .set(updateData)
      .where(eq(memberConnections.id, id));
  }

  // Job alert operations
  async createJobAlert(alert: InsertJobAlert): Promise<JobAlert> {
    const [newAlert] = await db
      .insert(jobAlerts)
      .values(alert)
      .returning();
    return newAlert;
  }

  async getJobAlertsByUserId(userId: string): Promise<JobAlert[]> {
    return await db
      .select()
      .from(jobAlerts)
      .where(eq(jobAlerts.userId, userId))
      .orderBy(desc(jobAlerts.createdAt));
  }

  async deleteJobAlert(id: number): Promise<void> {
    await db.delete(jobAlerts).where(eq(jobAlerts.id, id));
  }

  // Message operations
  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db
      .insert(messages)
      .values(message)
      .returning();
    return newMessage;
  }

  async getMessagesByUserId(userId: string, limit = 50, offset = 0): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(or(eq(messages.senderId, userId), eq(messages.receiverId, userId)))
      .orderBy(desc(messages.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getConversation(userId1: string, userId2: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(
        or(
          and(eq(messages.senderId, userId1), eq(messages.receiverId, userId2)),
          and(eq(messages.senderId, userId2), eq(messages.receiverId, userId1))
        )
      )
      .orderBy(asc(messages.createdAt));
  }

  async markMessageAsRead(messageId: number): Promise<void> {
    await db
      .update(messages)
      .set({ isRead: true })
      .where(eq(messages.id, messageId));
  }

  async getUnreadMessageCount(userId: string): Promise<number> {
    const result = await db
      .select({ count: count() })
      .from(messages)
      .where(and(eq(messages.receiverId, userId), eq(messages.isRead, false)));
    return result[0]?.count || 0;
  }

  // Notification operations
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db
      .insert(notifications)
      .values(notification)
      .returning();
    return newNotification;
  }

  async getNotificationsByUserId(userId: string, limit = 50): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt))
      .limit(limit);
  }

  async markNotificationAsRead(notificationId: number): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, notificationId));
  }

  async getUnreadNotificationCount(userId: string): Promise<number> {
    const result = await db
      .select({ count: count() })
      .from(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
    return result[0]?.count || 0;
  }

  // Review operations
  async createUserReview(review: InsertUserReview): Promise<UserReview> {
    const [newReview] = await db
      .insert(userReviews)
      .values(review)
      .returning();

    // Update user rating
    await this.updateUserRating(review.revieweeId, review.rating);

    return newReview;
  }

  async getUserReviews(userId: string): Promise<UserReview[]> {
    return await db
      .select()
      .from(userReviews)
      .where(and(eq(userReviews.revieweeId, userId), eq(userReviews.isPublic, true)))
      .orderBy(desc(userReviews.createdAt));
  }

  // Analytics operations
  async logUserAction(userId: string, actionType: string, resourceType?: string, resourceId?: string, metadata?: any): Promise<void> {
    await db.insert(userAnalytics).values({
      userId,
      actionType,
      resourceType,
      resourceId,
      metadata,
    });
  }

  async getUserAnalytics(userId: string, actionType?: string): Promise<UserAnalytics[]> {
    let query = db.select().from(userAnalytics).where(eq(userAnalytics.userId, userId));
    
    if (actionType) {
      query = query.where(eq(userAnalytics.actionType, actionType));
    }
    
    return await query.orderBy(desc(userAnalytics.timestamp));
  }

  // Video interaction operations
  async likeVideo(userId: string, videoId: number): Promise<VideoLike> {
    const [like] = await db
      .insert(videoLikes)
      .values({ userId, videoId })
      .returning();

    // Update like count
    await db
      .update(videoPortfolios)
      .set({
        likeCount: sql`${videoPortfolios.likeCount} + 1`,
      })
      .where(eq(videoPortfolios.id, videoId));

    return like;
  }

  async unlikeVideo(userId: string, videoId: number): Promise<void> {
    await db
      .delete(videoLikes)
      .where(and(eq(videoLikes.userId, userId), eq(videoLikes.videoId, videoId)));

    // Update like count
    await db
      .update(videoPortfolios)
      .set({
        likeCount: sql`${videoPortfolios.likeCount} - 1`,
      })
      .where(eq(videoPortfolios.id, videoId));
  }

  async isVideoLiked(userId: string, videoId: number): Promise<boolean> {
    const [like] = await db
      .select()
      .from(videoLikes)
      .where(and(eq(videoLikes.userId, userId), eq(videoLikes.videoId, videoId)));
    return !!like;
  }

  async addVideoComment(videoId: number, userId: string, comment: string, parentCommentId?: number): Promise<VideoComment> {
    const [newComment] = await db
      .insert(videoComments)
      .values({
        videoId,
        userId,
        comment,
        parentCommentId,
      })
      .returning();
    return newComment;
  }

  async getVideoComments(videoId: number): Promise<VideoComment[]> {
    return await db
      .select()
      .from(videoComments)
      .where(eq(videoComments.videoId, videoId))
      .orderBy(asc(videoComments.createdAt));
  }

  // Saved jobs operations
  async saveJob(userId: string, jobId: number, notes?: string): Promise<SavedJob> {
    const [savedJob] = await db
      .insert(savedJobs)
      .values({ userId, jobId, notes })
      .returning();
    return savedJob;
  }

  async unsaveJob(userId: string, jobId: number): Promise<void> {
    await db
      .delete(savedJobs)
      .where(and(eq(savedJobs.userId, userId), eq(savedJobs.jobId, jobId)));
  }

  async getSavedJobs(userId: string): Promise<SavedJob[]> {
    return await db
      .select()
      .from(savedJobs)
      .where(eq(savedJobs.userId, userId))
      .orderBy(desc(savedJobs.savedAt));
  }
}

export const storage = new DatabaseStorage();