import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { YouTubeService } from './youtube-service';

// Configure multer for video uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(process.cwd(), 'uploads', 'videos');
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    // Generate unique filename
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, `video-${uniqueSuffix}${ext}`);
  }
});

// File filter to only allow video files
const fileFilter = (req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  const allowedMimes = [
    'video/mp4',
    'video/quicktime',
    'video/x-msvideo',
    'video/webm',
    'video/ogg'
  ];
  
  if (allowedMimes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Only video files are allowed'));
  }
};

// Configure multer
export const videoUpload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 500 * 1024 * 1024, // 500MB max file size
  }
});

export interface VideoUploadResult {
  localPath: string;
  filename: string;
  size: number;
  mimetype: string;
  youtubeVideoId?: string;
  thumbnailUrl?: string;
  uploadStatus: 'local_only' | 'youtube_pending' | 'youtube_completed' | 'youtube_failed';
}

export class VideoUploadService {
  private youtubeService: YouTubeService;

  constructor(youtubeConfig?: {
    clientId: string;
    clientSecret: string;
    redirectUri: string;
  }) {
    if (youtubeConfig) {
      this.youtubeService = new YouTubeService(youtubeConfig);
    }
  }

  // Process uploaded video file
  async processVideoUpload(
    file: Express.Multer.File,
    videoData: {
      title: string;
      description: string;
      tradeCategory: string;
      skillsShowcased: string[];
      isPublic: boolean;
    },
    userTokens?: {
      accessToken: string;
      refreshToken?: string;
    }
  ): Promise<VideoUploadResult> {
    const result: VideoUploadResult = {
      localPath: file.path,
      filename: file.filename,
      size: file.size,
      mimetype: file.mimetype,
      uploadStatus: 'local_only'
    };

    // If YouTube integration is available and user has tokens
    if (this.youtubeService && userTokens) {
      try {
        // Set user tokens
        this.youtubeService.setTokens(userTokens.accessToken, userTokens.refreshToken);

        result.uploadStatus = 'youtube_pending';

        // Upload to YouTube
        const youtubeResult = await this.youtubeService.uploadVideo(
          file.path,
          {
            title: videoData.title,
            description: `${videoData.description}\n\nTrade Category: ${videoData.tradeCategory}\nSkills: ${videoData.skillsShowcased.join(', ')}`,
            tags: [videoData.tradeCategory, ...videoData.skillsShowcased, 'STEMulation', 'trades', 'portfolio'],
            categoryId: '22', // People & Blogs category
            privacyStatus: videoData.isPublic ? 'public' : 'unlisted'
          }
        );

        result.youtubeVideoId = youtubeResult.videoId;
        result.thumbnailUrl = youtubeResult.thumbnailUrl;
        result.uploadStatus = 'youtube_completed';

      } catch (error) {
        console.error('YouTube upload failed:', error);
        result.uploadStatus = 'youtube_failed';
        // Keep local file as fallback
      }
    }

    return result;
  }

  // Generate video thumbnail from local file
  async generateLocalThumbnail(videoPath: string): Promise<string> {
    // This would require ffmpeg or similar video processing library
    // For now, return a placeholder thumbnail path
    const thumbnailDir = path.join(process.cwd(), 'uploads', 'thumbnails');
    
    if (!fs.existsSync(thumbnailDir)) {
      fs.mkdirSync(thumbnailDir, { recursive: true });
    }

    const videoName = path.basename(videoPath, path.extname(videoPath));
    const thumbnailPath = path.join(thumbnailDir, `${videoName}-thumb.jpg`);
    
    // TODO: Implement actual thumbnail generation using ffmpeg
    // For now, return a default thumbnail path
    return `/uploads/thumbnails/${videoName}-thumb.jpg`;
  }

  // Get video duration (requires ffprobe or similar)
  async getVideoDuration(videoPath: string): Promise<number> {
    // TODO: Implement video duration detection
    // For now, return 0 as placeholder
    return 0;
  }

  // Clean up local video file
  async deleteLocalVideo(videoPath: string): Promise<void> {
    try {
      if (fs.existsSync(videoPath)) {
        fs.unlinkSync(videoPath);
      }
    } catch (error) {
      console.error('Failed to delete local video file:', error);
    }
  }

  // Sync video with YouTube (for re-upload or updates)
  async syncWithYouTube(
    videoId: number,
    localPath: string,
    videoData: {
      title: string;
      description: string;
      tradeCategory: string;
      skillsShowcased: string[];
      isPublic: boolean;
    },
    userTokens: {
      accessToken: string;
      refreshToken?: string;
    }
  ): Promise<{ youtubeVideoId: string; thumbnailUrl: string }> {
    if (!this.youtubeService) {
      throw new Error('YouTube service not configured');
    }

    this.youtubeService.setTokens(userTokens.accessToken, userTokens.refreshToken);

    return await this.youtubeService.uploadVideo(
      localPath,
      {
        title: videoData.title,
        description: `${videoData.description}\n\nTrade Category: ${videoData.tradeCategory}\nSkills: ${videoData.skillsShowcased.join(', ')}`,
        tags: [videoData.tradeCategory, ...videoData.skillsShowcased, 'STEMulation', 'trades', 'portfolio'],
        categoryId: '22',
        privacyStatus: videoData.isPublic ? 'public' : 'unlisted'
      }
    );
  }
}

// Utility function to validate video file
export function validateVideoFile(file: Express.Multer.File): { valid: boolean; error?: string } {
  const maxSize = 500 * 1024 * 1024; // 500MB
  const allowedTypes = ['video/mp4', 'video/quicktime', 'video/x-msvideo', 'video/webm', 'video/ogg'];

  if (file.size > maxSize) {
    return { valid: false, error: 'File size exceeds 500MB limit' };
  }

  if (!allowedTypes.includes(file.mimetype)) {
    return { valid: false, error: 'Invalid file type. Only video files are allowed.' };
  }

  return { valid: true };
}