import { google } from 'googleapis';
import fs from 'fs';
import path from 'path';

const youtube = google.youtube('v3');

interface YouTubeConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
}

interface VideoUploadData {
  title: string;
  description: string;
  tags: string[];
  categoryId: string;
  privacyStatus: 'private' | 'public' | 'unlisted';
}

export class YouTubeService {
  private oauth2Client: any;

  constructor(config: YouTubeConfig) {
    this.oauth2Client = new google.auth.OAuth2(
      config.clientId,
      config.clientSecret,
      config.redirectUri
    );
  }

  // Generate auth URL for user consent
  generateAuthUrl(): string {
    const scopes = [
      'https://www.googleapis.com/auth/youtube.upload',
      'https://www.googleapis.com/auth/youtube'
    ];

    return this.oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent'
    });
  }

  // Exchange authorization code for tokens
  async getTokens(code: string) {
    const { tokens } = await this.oauth2Client.getToken(code);
    this.oauth2Client.setCredentials(tokens);
    return tokens;
  }

  // Set stored tokens
  setTokens(accessToken: string, refreshToken?: string) {
    this.oauth2Client.setCredentials({
      access_token: accessToken,
      refresh_token: refreshToken
    });
  }

  // Upload video to YouTube
  async uploadVideo(
    filePath: string,
    videoData: VideoUploadData,
    onProgress?: (progress: number) => void
  ): Promise<{ videoId: string; thumbnailUrl: string }> {
    try {
      const fileSize = fs.statSync(filePath).size;
      const fileStream = fs.createReadStream(filePath);

      const response = await youtube.videos.insert({
        auth: this.oauth2Client,
        part: ['snippet', 'status'],
        requestBody: {
          snippet: {
            title: videoData.title,
            description: videoData.description,
            tags: videoData.tags,
            categoryId: videoData.categoryId,
          },
          status: {
            privacyStatus: videoData.privacyStatus,
          },
        },
        media: {
          body: fileStream,
        },
      });

      const videoId = response.data.id!;
      const thumbnailUrl = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;

      return { videoId, thumbnailUrl };
    } catch (error) {
      console.error('YouTube upload error:', error);
      throw new Error('Failed to upload video to YouTube');
    }
  }

  // Update video metadata
  async updateVideo(videoId: string, videoData: Partial<VideoUploadData>) {
    try {
      await youtube.videos.update({
        auth: this.oauth2Client,
        part: ['snippet', 'status'],
        requestBody: {
          id: videoId,
          snippet: {
            title: videoData.title,
            description: videoData.description,
            tags: videoData.tags,
            categoryId: videoData.categoryId,
          },
          status: {
            privacyStatus: videoData.privacyStatus,
          },
        },
      });
    } catch (error) {
      console.error('YouTube update error:', error);
      throw new Error('Failed to update video on YouTube');
    }
  }

  // Delete video from YouTube
  async deleteVideo(videoId: string) {
    try {
      await youtube.videos.delete({
        auth: this.oauth2Client,
        id: videoId,
      });
    } catch (error) {
      console.error('YouTube delete error:', error);
      throw new Error('Failed to delete video from YouTube');
    }
  }

  // Get video details
  async getVideoDetails(videoId: string) {
    try {
      const response = await youtube.videos.list({
        auth: this.oauth2Client,
        part: ['snippet', 'statistics', 'status'],
        id: [videoId],
      });

      return response.data.items?.[0];
    } catch (error) {
      console.error('YouTube get video error:', error);
      throw new Error('Failed to get video details from YouTube');
    }
  }

  // Get user's channel info
  async getChannelInfo() {
    try {
      const response = await youtube.channels.list({
        auth: this.oauth2Client,
        part: ['snippet', 'statistics'],
        mine: true,
      });

      return response.data.items?.[0];
    } catch (error) {
      console.error('YouTube get channel error:', error);
      throw new Error('Failed to get channel info from YouTube');
    }
  }

  // Refresh access token
  async refreshTokens() {
    try {
      const { credentials } = await this.oauth2Client.refreshAccessToken();
      this.oauth2Client.setCredentials(credentials);
      return credentials;
    } catch (error) {
      console.error('YouTube token refresh error:', error);
      throw new Error('Failed to refresh YouTube tokens');
    }
  }
}

// Utility function to get video thumbnail
export function getYouTubeThumbnail(videoId: string, quality: 'default' | 'hqdefault' | 'maxresdefault' = 'hqdefault'): string {
  return `https://img.youtube.com/vi/${videoId}/${quality}.jpg`;
}

// Utility function to get embeddable YouTube URL
export function getYouTubeEmbedUrl(videoId: string): string {
  return `https://www.youtube.com/embed/${videoId}`;
}

// Utility function to extract video ID from YouTube URL
export function extractYouTubeVideoId(url: string): string | null {
  const regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#&?]*).*/;
  const match = url.match(regExp);
  return (match && match[7].length === 11) ? match[7] : null;
}