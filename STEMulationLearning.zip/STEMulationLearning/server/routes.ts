import type { Express } from "express";
import { createServer, type Server } from "http";
import express from "express";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { videoUpload, VideoUploadService, validateVideoFile } from "./upload-service";
import { YouTubeService, getYouTubeThumbnail, extractYouTubeVideoId } from "./youtube-service";
import { RateLimiterMemory } from "rate-limiter-flexible";
import cron from "node-cron";

// Rate limiters
const generalLimiter = new RateLimiterMemory({
  keyPrefix: 'general',
  points: 100, // Number of requests
  duration: 60, // Per 60 seconds
});

const uploadLimiter = new RateLimiterMemory({
  keyPrefix: 'upload',
  points: 5, // Number of uploads
  duration: 3600, // Per hour
});

const messageLimiter = new RateLimiterMemory({
  keyPrefix: 'message',
  points: 50, // Number of messages
  duration: 3600, // Per hour
});

// Initialize services
const videoUploadService = new VideoUploadService();

// Scheduled job for processing job alerts
cron.schedule('0 */6 * * *', async () => {
  console.log('Processing job alerts...');
  // TODO: Implement job alert processing
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Rate limiting middleware
  const rateLimitMiddleware = async (req: any, res: any, next: any) => {
    try {
      await generalLimiter.consume(req.ip);
      next();
    } catch (rejRes) {
      res.status(429).json({ message: 'Too many requests' });
    }
  };

  app.use('/api', rateLimitMiddleware);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Log user login
      await storage.logUserAction(userId, 'login');
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Enhanced User Profile Routes
  app.put('/api/user/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const updates = req.body;
      
      const user = await storage.updateUserProfile(userId, updates);
      await storage.logUserAction(userId, 'profile_update');
      
      res.json(user);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.put('/api/user/profiles', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { linkedinProfileUrl, indeedProfileUrl } = req.body;
      
      const user = await storage.updateUserProfiles(userId, {
        linkedinProfileUrl,
        indeedProfileUrl
      });
      
      res.json(user);
    } catch (error) {
      console.error("Error updating profile connections:", error);
      res.status(500).json({ message: "Failed to update profile connections" });
    }
  });

  // YouTube Integration Routes
  app.post('/api/youtube/auth', isAuthenticated, async (req: any, res) => {
    try {
      const { accessToken, refreshToken, channelId } = req.body;
      const userId = req.user.claims.sub;
      
      const user = await storage.updateUserYouTubeTokens(userId, {
        accessToken,
        refreshToken,
        channelId
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error saving YouTube tokens:", error);
      res.status(500).json({ message: "Failed to save YouTube tokens" });
    }
  });

  // Enhanced Job Posting Routes
  app.get('/api/job-postings', async (req, res) => {
    try {
      const { page = 1, limit = 20, category, location, search, salaryMin, experienceLevel } = req.query;
      const offset = (Number(page) - 1) * Number(limit);

      let jobs;
      if (search || location || salaryMin || experienceLevel) {
        const searchQuery = {
          keywords: search ? [search as string] : undefined,
          location: location as string,
          tradeCategory: category as string,
          salaryMin: salaryMin ? Number(salaryMin) : undefined,
          experienceLevel: experienceLevel as string,
        };
        jobs = await storage.searchJobPostings(searchQuery, Number(limit), offset);
      } else if (category) {
        jobs = await storage.getJobPostingsByCategory(category as string, Number(limit), offset);
      } else {
        jobs = await storage.getAllJobPostings(Number(limit), offset);
      }

      res.json(jobs);
    } catch (error) {
      console.error("Error fetching job postings:", error);
      res.status(500).json({ message: "Failed to fetch job postings" });
    }
  });

  app.get('/api/job-postings/featured', async (req, res) => {
    try {
      const jobs = await storage.getFeaturedJobPostings(10);
      res.json(jobs);
    } catch (error) {
      console.error("Error fetching featured jobs:", error);
      res.status(500).json({ message: "Failed to fetch featured jobs" });
    }
  });

  app.get('/api/job-postings/:id', async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const job = await storage.getJobPosting(jobId);
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }

      // Increment view count
      await storage.incrementJobViewCount(jobId);
      
      res.json(job);
    } catch (error) {
      console.error("Error fetching job posting:", error);
      res.status(500).json({ message: "Failed to fetch job posting" });
    }
  });

  app.post('/api/job-postings', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobData = { ...req.body, postedBy: userId };
      
      const job = await storage.createJobPosting(jobData);
      await storage.logUserAction(userId, 'job_posting_created', 'job', job.id.toString());
      
      res.json(job);
    } catch (error) {
      console.error("Error creating job posting:", error);
      res.status(500).json({ message: "Failed to create job posting" });
    }
  });

  app.put('/api/job-postings/:id', isAuthenticated, async (req: any, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check ownership
      const existingJob = await storage.getJobPosting(jobId);
      if (!existingJob || existingJob.postedBy !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const job = await storage.updateJobPosting(jobId, req.body);
      res.json(job);
    } catch (error) {
      console.error("Error updating job posting:", error);
      res.status(500).json({ message: "Failed to update job posting" });
    }
  });

  app.delete('/api/job-postings/:id', isAuthenticated, async (req: any, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check ownership
      const existingJob = await storage.getJobPosting(jobId);
      if (!existingJob || existingJob.postedBy !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      await storage.deleteJobPosting(jobId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting job posting:", error);
      res.status(500).json({ message: "Failed to delete job posting" });
    }
  });

  // Enhanced Video Portfolio Routes with YouTube Integration
  app.post('/api/video-portfolios/upload', isAuthenticated, videoUpload.single('video'), async (req: any, res) => {
    try {
      await uploadLimiter.consume(req.ip);
      
      const userId = req.user.claims.sub;
      const file = req.file;
      
      if (!file) {
        return res.status(400).json({ message: "No video file provided" });
      }

      const validation = validateVideoFile(file);
      if (!validation.valid) {
        return res.status(400).json({ message: validation.error });
      }

      const { title, description, tradeCategory, skillsShowcased, isPublic } = req.body;
      const skillsArray = Array.isArray(skillsShowcased) ? skillsShowcased : [skillsShowcased];

      // Get user's YouTube tokens
      const user = await storage.getUser(userId);
      const youtubeTokens = user?.youtubeAccessToken ? {
        accessToken: user.youtubeAccessToken,
        refreshToken: user.youtubeRefreshToken
      } : undefined;

      // Process video upload
      const uploadResult = await videoUploadService.processVideoUpload(
        file,
        {
          title,
          description,
          tradeCategory,
          skillsShowcased: skillsArray,
          isPublic: isPublic === 'true'
        },
        youtubeTokens
      );

      // Create video portfolio record
      const videoPortfolio = await storage.createVideoPortfolio({
        userId,
        title,
        description,
        videoUrl: file.path,
        youtubeVideoId: uploadResult.youtubeVideoId,
        thumbnailUrl: uploadResult.thumbnailUrl,
        localVideoPath: uploadResult.localPath,
        tradeCategory,
        skillsShowcased: skillsArray,
        uploadStatus: uploadResult.uploadStatus,
        duration: await videoUploadService.getVideoDuration(uploadResult.localPath),
        fileSize: uploadResult.size,
        isPublic: isPublic === 'true'
      });

      await storage.logUserAction(userId, 'video_uploaded', 'video', videoPortfolio.id.toString());

      res.json(videoPortfolio);
    } catch (rejRes) {
      if (rejRes.msBeforeNext) {
        res.status(429).json({ message: 'Upload limit exceeded. Try again later.' });
      } else {
        console.error("Error uploading video:", rejRes);
        res.status(500).json({ message: "Failed to upload video" });
      }
    }
  });

  app.get('/api/video-portfolios', async (req, res) => {
    try {
      const { page = 1, limit = 20, category, userId: targetUserId } = req.query;
      const offset = (Number(page) - 1) * Number(limit);

      let videos;
      if (targetUserId) {
        videos = await storage.getVideoPortfoliosByUserId(targetUserId as string);
      } else if (category) {
        videos = await storage.getVideoPortfoliosByCategory(category as string, Number(limit), offset);
      } else {
        videos = await storage.getAllVideoPortfolios(Number(limit), offset);
      }

      res.json(videos);
    } catch (error) {
      console.error("Error fetching video portfolios:", error);
      res.status(500).json({ message: "Failed to fetch video portfolios" });
    }
  });

  app.get('/api/my-videos', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const videos = await storage.getVideoPortfoliosByUserId(userId);
      res.json(videos);
    } catch (error) {
      console.error("Error fetching user videos:", error);
      res.status(500).json({ message: "Failed to fetch user videos" });
    }
  });

  app.get('/api/video-portfolios/:id', async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const video = await storage.getVideoPortfolio(videoId);
      
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }

      // Increment view count
      await storage.incrementVideoViewCount(videoId);
      
      res.json(video);
    } catch (error) {
      console.error("Error fetching video:", error);
      res.status(500).json({ message: "Failed to fetch video" });
    }
  });

  // Video Interaction Routes
  app.post('/api/video-portfolios/:id/like', isAuthenticated, async (req: any, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      const isLiked = await storage.isVideoLiked(userId, videoId);
      
      if (isLiked) {
        await storage.unlikeVideo(userId, videoId);
        res.json({ liked: false });
      } else {
        await storage.likeVideo(userId, videoId);
        res.json({ liked: true });
      }
    } catch (error) {
      console.error("Error toggling video like:", error);
      res.status(500).json({ message: "Failed to toggle like" });
    }
  });

  app.get('/api/video-portfolios/:id/comments', async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const comments = await storage.getVideoComments(videoId);
      res.json(comments);
    } catch (error) {
      console.error("Error fetching comments:", error);
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  app.post('/api/video-portfolios/:id/comments', isAuthenticated, async (req: any, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const { comment, parentCommentId } = req.body;
      
      const newComment = await storage.addVideoComment(videoId, userId, comment, parentCommentId);
      res.json(newComment);
    } catch (error) {
      console.error("Error adding comment:", error);
      res.status(500).json({ message: "Failed to add comment" });
    }
  });

  // Job Application Routes
  app.post('/api/job-applications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applicationData = { ...req.body, applicantId: userId };
      
      const application = await storage.createJobApplication(applicationData);
      await storage.logUserAction(userId, 'job_application_submitted', 'job', applicationData.jobId.toString());
      
      res.json(application);
    } catch (error) {
      console.error("Error creating job application:", error);
      res.status(500).json({ message: "Failed to create job application" });
    }
  });

  app.get('/api/job-applications/my-applications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applications = await storage.getJobApplicationsByUserId(userId);
      res.json(applications);
    } catch (error) {
      console.error("Error fetching applications:", error);
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });

  app.get('/api/job-applications/job/:jobId', isAuthenticated, async (req: any, res) => {
    try {
      const jobId = parseInt(req.params.jobId);
      const userId = req.user.claims.sub;
      
      // Check if user owns the job posting
      const job = await storage.getJobPosting(jobId);
      if (!job || job.postedBy !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const applications = await storage.getJobApplicationsByJobId(jobId);
      res.json(applications);
    } catch (error) {
      console.error("Error fetching job applications:", error);
      res.status(500).json({ message: "Failed to fetch job applications" });
    }
  });

  app.put('/api/job-applications/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const applicationId = parseInt(req.params.id);
      const { status, notes } = req.body;
      
      const application = await storage.updateJobApplicationStatus(applicationId, status, notes);
      res.json(application);
    } catch (error) {
      console.error("Error updating application status:", error);
      res.status(500).json({ message: "Failed to update application status" });
    }
  });

  // Message System Routes
  app.post('/api/messages', isAuthenticated, async (req: any, res) => {
    try {
      await messageLimiter.consume(req.ip);
      
      const senderId = req.user.claims.sub;
      const messageData = { ...req.body, senderId };
      
      const message = await storage.createMessage(messageData);
      
      // Create notification for receiver
      await storage.createNotification({
        userId: messageData.receiverId,
        title: 'New Message',
        message: `You have a new message from ${req.user.claims.first_name || 'a user'}`,
        type: 'message',
        relatedId: message.id
      });
      
      res.json(message);
    } catch (rejRes) {
      if (rejRes.msBeforeNext) {
        res.status(429).json({ message: 'Message limit exceeded. Try again later.' });
      } else {
        console.error("Error sending message:", rejRes);
        res.status(500).json({ message: "Failed to send message" });
      }
    }
  });

  app.get('/api/messages', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { page = 1, limit = 50 } = req.query;
      const offset = (Number(page) - 1) * Number(limit);
      
      const messages = await storage.getMessagesByUserId(userId, Number(limit), offset);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.get('/api/messages/conversation/:userId', isAuthenticated, async (req: any, res) => {
    try {
      const currentUserId = req.user.claims.sub;
      const otherUserId = req.params.userId;
      
      const conversation = await storage.getConversation(currentUserId, otherUserId);
      res.json(conversation);
    } catch (error) {
      console.error("Error fetching conversation:", error);
      res.status(500).json({ message: "Failed to fetch conversation" });
    }
  });

  app.put('/api/messages/:id/read', isAuthenticated, async (req: any, res) => {
    try {
      const messageId = parseInt(req.params.id);
      await storage.markMessageAsRead(messageId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking message as read:", error);
      res.status(500).json({ message: "Failed to mark message as read" });
    }
  });

  app.get('/api/messages/unread-count', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const count = await storage.getUnreadMessageCount(userId);
      res.json({ count });
    } catch (error) {
      console.error("Error fetching unread count:", error);
      res.status(500).json({ message: "Failed to fetch unread count" });
    }
  });

  // Notification Routes
  app.get('/api/notifications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { limit = 50 } = req.query;
      
      const notifications = await storage.getNotificationsByUserId(userId, Number(limit));
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.put('/api/notifications/:id/read', isAuthenticated, async (req: any, res) => {
    try {
      const notificationId = parseInt(req.params.id);
      await storage.markNotificationAsRead(notificationId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.get('/api/notifications/unread-count', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const count = await storage.getUnreadNotificationCount(userId);
      res.json({ count });
    } catch (error) {
      console.error("Error fetching unread count:", error);
      res.status(500).json({ message: "Failed to fetch unread count" });
    }
  });

  // Saved Jobs Routes
  app.post('/api/saved-jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { jobId, notes } = req.body;
      
      const savedJob = await storage.saveJob(userId, jobId, notes);
      res.json(savedJob);
    } catch (error) {
      console.error("Error saving job:", error);
      res.status(500).json({ message: "Failed to save job" });
    }
  });

  app.get('/api/saved-jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const savedJobs = await storage.getSavedJobs(userId);
      res.json(savedJobs);
    } catch (error) {
      console.error("Error fetching saved jobs:", error);
      res.status(500).json({ message: "Failed to fetch saved jobs" });
    }
  });

  app.delete('/api/saved-jobs/:jobId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobId = parseInt(req.params.jobId);
      
      await storage.unsaveJob(userId, jobId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error unsaving job:", error);
      res.status(500).json({ message: "Failed to unsave job" });
    }
  });

  // Job Alert Routes
  app.post('/api/job-alerts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const alertData = { ...req.body, userId };
      
      const alert = await storage.createJobAlert(alertData);
      res.json(alert);
    } catch (error) {
      console.error("Error creating job alert:", error);
      res.status(500).json({ message: "Failed to create job alert" });
    }
  });

  app.get('/api/job-alerts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const alerts = await storage.getJobAlertsByUserId(userId);
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching job alerts:", error);
      res.status(500).json({ message: "Failed to fetch job alerts" });
    }
  });

  app.delete('/api/job-alerts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const alertId = parseInt(req.params.id);
      await storage.deleteJobAlert(alertId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting job alert:", error);
      res.status(500).json({ message: "Failed to delete job alert" });
    }
  });

  // Member Connection Routes
  app.post('/api/member-connections', isAuthenticated, async (req: any, res) => {
    try {
      const requesterId = req.user.claims.sub;
      const connectionData = { ...req.body, requesterId };
      
      const connection = await storage.createMemberConnection(connectionData);
      
      // Create notification for receiver
      await storage.createNotification({
        userId: connectionData.receiverId,
        title: 'New Connection Request',
        message: `${req.user.claims.first_name || 'A user'} wants to connect with you`,
        type: 'connection',
        relatedId: connection.id
      });
      
      res.json(connection);
    } catch (error) {
      console.error("Error creating connection:", error);
      res.status(500).json({ message: "Failed to create connection" });
    }
  });

  app.get('/api/member-connections', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const connections = await storage.getMemberConnectionsByUserId(userId);
      res.json(connections);
    } catch (error) {
      console.error("Error fetching connections:", error);
      res.status(500).json({ message: "Failed to fetch connections" });
    }
  });

  app.put('/api/member-connections/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const connectionId = parseInt(req.params.id);
      const { status } = req.body;
      
      await storage.updateMemberConnectionStatus(connectionId, status);
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating connection status:", error);
      res.status(500).json({ message: "Failed to update connection status" });
    }
  });

  // User Review Routes
  app.post('/api/user-reviews', isAuthenticated, async (req: any, res) => {
    try {
      const reviewerId = req.user.claims.sub;
      const reviewData = { ...req.body, reviewerId };
      
      const review = await storage.createUserReview(reviewData);
      res.json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  app.get('/api/user-reviews/:userId', async (req, res) => {
    try {
      const userId = req.params.userId;
      const reviews = await storage.getUserReviews(userId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  // Analytics Routes
  app.get('/api/analytics/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { actionType } = req.query;
      
      const analytics = await storage.getUserAnalytics(userId, actionType as string);
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  // Legacy routes for backward compatibility
  app.get('/api/employer-groups', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const groups = await storage.getEmployerGroupsByUserId(userId);
      res.json(groups);
    } catch (error) {
      console.error("Error fetching employer groups:", error);
      res.status(500).json({ message: "Failed to fetch employer groups" });
    }
  });

  app.post('/api/employer-groups', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const groupData = { ...req.body, employerId: userId };
      
      const group = await storage.createEmployerGroup(groupData);
      res.json(group);
    } catch (error) {
      console.error("Error creating employer group:", error);
      res.status(500).json({ message: "Failed to create employer group" });
    }
  });

  app.get('/api/training-modules/:groupId', isAuthenticated, async (req, res) => {
    try {
      const groupId = parseInt(req.params.groupId);
      const modules = await storage.getTrainingModulesByGroupId(groupId);
      res.json(modules);
    } catch (error) {
      console.error("Error fetching training modules:", error);
      res.status(500).json({ message: "Failed to fetch training modules" });
    }
  });

  app.post('/api/training-modules', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const moduleData = { ...req.body, createdById: userId };
      
      const module = await storage.createTrainingModule(moduleData);
      res.json(module);
    } catch (error) {
      console.error("Error creating training module:", error);
      res.status(500).json({ message: "Failed to create training module" });
    }
  });

  // Serve uploaded files
  app.use('/uploads', express.static('uploads'));

  const httpServer = createServer(app);
  return httpServer;
}