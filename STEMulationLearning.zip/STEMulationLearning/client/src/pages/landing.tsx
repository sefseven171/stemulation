import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import HeroSection from "@/components/hero-section";
import TradeCategories from "@/components/trade-categories";
import SponsorsSection from "@/components/sponsors-section";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <HeroSection />
      <TradeCategories />
      <SponsorsSection />
      <Footer />
    </div>
  );
}
