import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent } from "@/components/ui/card";

export default function Mission() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Our Mission</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Empowering the next generation of skilled trades professionals through innovative education and industry partnerships.
          </p>
        </div>

        <Card className="mb-12">
          <CardContent className="p-8">
            <div className="prose max-w-none">
              <h2 className="text-2xl font-semibold text-gray-900 mb-6">Building Tomorrow's Workforce Today</h2>
              
              <p className="text-lg text-gray-700 mb-6">
                Our mission is to bridge the skills gap in construction trades by providing comprehensive, accessible, 
                and industry-relevant training programs that empower individuals to build successful careers while 
                supporting the growth of the construction industry.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">What We Believe</h3>
                  <ul className="space-y-3 text-gray-700">
                    <li className="flex items-start">
                      <span className="text-primary mr-2 mt-1">✓</span>
                      Every individual deserves access to quality trade education
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-2 mt-1">✓</span>
                      Hands-on learning creates the most effective professionals
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-2 mt-1">✓</span>
                      Industry partnerships ensure relevant, current training
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-2 mt-1">✓</span>
                      Technology enhances traditional trades education
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Our Impact Goals</h3>
                  <ul className="space-y-3 text-gray-700">
                    <li className="flex items-start">
                      <span className="text-secondary mr-2 mt-1">→</span>
                      Train 10,000+ skilled professionals by 2030
                    </li>
                    <li className="flex items-start">
                      <span className="text-secondary mr-2 mt-1">→</span>
                      Partner with 500+ construction companies
                    </li>
                    <li className="flex items-start">
                      <span className="text-secondary mr-2 mt-1">→</span>
                      Achieve 90%+ job placement rate for graduates
                    </li>
                    <li className="flex items-start">
                      <span className="text-secondary mr-2 mt-1">→</span>
                      Increase diversity in the trades workforce
                    </li>
                  </ul>
                </div>
              </div>

              <h3 className="text-xl font-semibold text-gray-900 mb-4">Our Commitment to Excellence</h3>
              <p className="text-gray-700 mb-4">
                We are committed to maintaining the highest standards in trade education by continuously updating 
                our curriculum to reflect industry best practices, incorporating the latest technologies and safety 
                protocols, and ensuring our instructors are experienced professionals who bring real-world expertise 
                to the classroom.
              </p>

              <p className="text-gray-700 mb-6">
                Through our comprehensive approach that combines theoretical knowledge with practical application, 
                we prepare our students not just for their first job, but for lifelong careers in the trades. 
                We believe that by investing in people, we're investing in the future of the construction industry.
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="bg-primary bg-opacity-10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-graduation-cap text-2xl text-primary"></i>
              </div>
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Education Excellence</h4>
              <p className="text-gray-600 text-sm">
                Providing world-class training programs that meet industry standards and exceed expectations.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="bg-secondary bg-opacity-10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-handshake text-2xl text-secondary"></i>
              </div>
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Industry Partnership</h4>
              <p className="text-gray-600 text-sm">
                Collaborating with leading employers to ensure our training meets real-world needs.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="bg-accent bg-opacity-10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-rocket text-2xl text-accent"></i>
              </div>
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Career Growth</h4>
              <p className="text-gray-600 text-sm">
                Supporting professionals throughout their careers with ongoing education and opportunities.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <h3 className="text-2xl font-semibold text-gray-900 mb-4">Join Our Mission</h3>
          <p className="text-lg text-gray-600 mb-8">
            Be part of the solution to the skilled trades shortage. Together, we can build a stronger future.
          </p>
          <button 
            onClick={() => window.location.href = "/api/login"}
            className="bg-primary text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors shadow-lg"
          >
            <i className="fas fa-tools mr-2"></i>
            Get Started Today
          </button>
        </div>
      </main>

      <Footer />
    </div>
  );
}
