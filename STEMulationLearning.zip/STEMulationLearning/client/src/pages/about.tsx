import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent } from "@/components/ui/card";

export default function About() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About STEMulation Learning</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Bridging the skills gap in construction trades through comprehensive, accessible, and industry-relevant training programs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <Card>
            <CardContent className="p-8">
              <h3 className="text-2xl font-semibold text-gray-900 mb-4">Our Story</h3>
              <p className="text-gray-600 mb-4">
                Founded with the vision of empowering individuals to build successful careers in the construction industry, 
                STEMulation Learning has become a trusted platform for skilled trades education and professional development.
              </p>
              <p className="text-gray-600">
                We understand that the construction industry faces a significant skills gap, and we're committed to 
                providing the training and resources needed to close that gap while supporting career advancement 
                for trade professionals.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-8">
              <h3 className="text-2xl font-semibold text-gray-900 mb-4">What We Offer</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start">
                  <span className="text-primary mr-2">•</span>
                  Comprehensive training in six core trade specializations
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">•</span>
                  Job placement assistance and employer connections
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">•</span>
                  Professional networking and mentorship opportunities
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">•</span>
                  Video portfolio platform for showcasing skills
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">•</span>
                  Employer tools for workforce development
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-12">
          <CardContent className="p-8">
            <h3 className="text-2xl font-semibold text-gray-900 mb-6 text-center">Our Trade Specializations</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="bg-primary bg-opacity-10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-wrench text-2xl text-primary"></i>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Plumbing</h4>
                <p className="text-sm text-gray-600">Water systems, pipe installation, and repair techniques</p>
              </div>
              
              <div className="text-center">
                <div className="bg-secondary bg-opacity-10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-cogs text-2xl text-secondary"></i>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Mechanical</h4>
                <p className="text-sm text-gray-600">Mechanical systems and equipment maintenance</p>
              </div>
              
              <div className="text-center">
                <div className="bg-accent bg-opacity-10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-thermometer-half text-2xl text-accent"></i>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">HVAC</h4>
                <p className="text-sm text-gray-600">Heating, ventilation, and air conditioning systems</p>
              </div>
              
              <div className="text-center">
                <div className="bg-yellow-500 bg-opacity-10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-bolt text-2xl text-yellow-600"></i>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Electrical</h4>
                <p className="text-sm text-gray-600">Electrical systems and power distribution</p>
              </div>
              
              <div className="text-center">
                <div className="bg-amber-500 bg-opacity-10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-hammer text-2xl text-amber-600"></i>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Carpentry</h4>
                <p className="text-sm text-gray-600">Woodworking and construction techniques</p>
              </div>
              
              <div className="text-center">
                <div className="bg-green-500 bg-opacity-10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-microchip text-2xl text-green-600"></i>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Energy Building Automation</h4>
                <p className="text-sm text-gray-600">Smart building systems and energy management</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center">
          <h3 className="text-2xl font-semibold text-gray-900 mb-4">Ready to Start Your Journey?</h3>
          <p className="text-lg text-gray-600 mb-8">
            Join thousands of professionals who have advanced their careers through STEMulation Learning.
          </p>
          <button 
            onClick={() => window.location.href = "/api/login"}
            className="bg-primary text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors shadow-lg"
          >
            <i className="fas fa-tools mr-2"></i>
            Enter the Workshop
          </button>
        </div>
      </main>

      <Footer />
    </div>
  );
}
