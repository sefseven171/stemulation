import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Users, GraduationCap, Settings, Calendar } from "lucide-react";
import type { EmployerGroup, TrainingModule } from "@shared/schema";

export default function EmployerDashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [isCreateGroupOpen, setIsCreateGroupOpen] = useState(false);
  const [isCreateModuleOpen, setIsCreateModuleOpen] = useState(false);
  const [selectedGroupId, setSelectedGroupId] = useState<number | null>(null);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: employerGroups, isLoading: groupsLoading } = useQuery({
    queryKey: ["/api/employer-groups"],
    enabled: !!isAuthenticated,
  });

  const { data: trainingModules, isLoading: modulesLoading } = useQuery({
    queryKey: ["/api/training-modules", selectedGroupId],
    enabled: !!isAuthenticated && !!selectedGroupId,
  });

  const createGroupMutation = useMutation({
    mutationFn: async (groupData: any) => {
      await apiRequest("POST", "/api/employer-groups", groupData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employer-groups"] });
      setIsCreateGroupOpen(false);
      toast({
        title: "Success",
        description: "Employee group created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create employee group. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createModuleMutation = useMutation({
    mutationFn: async (moduleData: any) => {
      await apiRequest("POST", "/api/training-modules", moduleData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/training-modules"] });
      setIsCreateModuleOpen(false);
      toast({
        title: "Success",
        description: "Training module created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create training module. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateGroup = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const groupData = {
      name: formData.get("name") as string,
      description: formData.get("description") as string,
    };
    createGroupMutation.mutate(groupData);
  };

  const handleCreateModule = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const moduleData = {
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      content: formData.get("content") as string,
      groupId: selectedGroupId,
    };
    createModuleMutation.mutate(moduleData);
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Employer Dashboard</h1>
          <p className="text-lg text-gray-600">Manage your workforce training and development programs</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Employee Groups Section */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <Users className="h-5 w-5 mr-2 text-primary" />
                  <CardTitle>Employee Groups</CardTitle>
                </div>
                <Dialog open={isCreateGroupOpen} onOpenChange={setIsCreateGroupOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="h-4 w-4 mr-2" />
                      Create Group
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Create Employee Group</DialogTitle>
                      <DialogDescription>
                        Create a new group to manage employee training
                      </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleCreateGroup} className="space-y-4">
                      <div>
                        <Label htmlFor="name">Group Name</Label>
                        <Input name="name" required placeholder="e.g., Safety Training Group" />
                      </div>
                      <div>
                        <Label htmlFor="description">Description</Label>
                        <Textarea 
                          name="description" 
                          rows={3}
                          placeholder="Describe the purpose of this group..."
                        />
                      </div>
                      <Button type="submit" disabled={createGroupMutation.isPending}>
                        {createGroupMutation.isPending ? "Creating..." : "Create Group"}
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
              <CardDescription>
                Create and manage employee groups with customized training programs
              </CardDescription>
            </CardHeader>
            <CardContent>
              {groupsLoading ? (
                <div className="text-center py-4">Loading groups...</div>
              ) : !employerGroups || employerGroups.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <h3 className="text-lg font-medium mb-2">No groups created yet</h3>
                  <p className="text-sm">Create your first employee group to get started</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {employerGroups.map((group: EmployerGroup) => (
                    <div 
                      key={group.id} 
                      className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                        selectedGroupId === group.id ? 'border-primary bg-blue-50' : 'border-gray-200 hover:bg-gray-50'
                      }`}
                      onClick={() => setSelectedGroupId(group.id)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium text-gray-900">{group.name}</h4>
                          {group.description && (
                            <p className="text-sm text-gray-600 mt-1">{group.description}</p>
                          )}
                          <div className="flex items-center mt-2 text-sm text-gray-500">
                            <Calendar className="h-3 w-3 mr-1" />
                            Created {new Date(group.createdAt!).toLocaleDateString()}
                          </div>
                        </div>
                        <Button size="sm" variant="outline">
                          <Settings className="h-3 w-3 mr-1" />
                          Manage
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Training Modules Section */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <GraduationCap className="h-5 w-5 mr-2 text-secondary" />
                  <CardTitle>Training Modules</CardTitle>
                </div>
                <Dialog open={isCreateModuleOpen} onOpenChange={setIsCreateModuleOpen}>
                  <DialogTrigger asChild>
                    <Button 
                      disabled={!selectedGroupId}
                      variant={selectedGroupId ? "default" : "outline"}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Create Module
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Create Training Module</DialogTitle>
                      <DialogDescription>
                        Build custom onboarding and job-specific training programs
                      </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleCreateModule} className="space-y-4">
                      <div>
                        <Label htmlFor="name">Module Name</Label>
                        <Input name="name" required placeholder="e.g., OSHA Safety Standards" />
                      </div>
                      <div>
                        <Label htmlFor="description">Description</Label>
                        <Textarea 
                          name="description" 
                          rows={2}
                          placeholder="Brief description of the training module..."
                        />
                      </div>
                      <div>
                        <Label htmlFor="content">Training Content</Label>
                        <Textarea 
                          name="content" 
                          rows={6}
                          placeholder="Enter the training content, objectives, and materials..."
                        />
                      </div>
                      <Button type="submit" disabled={createModuleMutation.isPending}>
                        {createModuleMutation.isPending ? "Creating..." : "Create Module"}
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
              <CardDescription>
                {selectedGroupId 
                  ? "Build custom training programs for the selected group"
                  : "Select a group to manage training modules"
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!selectedGroupId ? (
                <div className="text-center py-8 text-gray-500">
                  <GraduationCap className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <h3 className="text-lg font-medium mb-2">Select a Group</h3>
                  <p className="text-sm">Choose an employee group to view and manage training modules</p>
                </div>
              ) : modulesLoading ? (
                <div className="text-center py-4">Loading modules...</div>
              ) : !trainingModules || trainingModules.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <GraduationCap className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <h3 className="text-lg font-medium mb-2">No training modules</h3>
                  <p className="text-sm">Create your first training module for this group</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {trainingModules.map((module: TrainingModule) => (
                    <div key={module.id} className="p-4 border border-gray-200 rounded-lg">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium text-gray-900">{module.name}</h4>
                          {module.description && (
                            <p className="text-sm text-gray-600 mt-1">{module.description}</p>
                          )}
                          <div className="flex items-center mt-2">
                            <Badge variant="outline" className="text-xs">
                              Active
                            </Badge>
                            <span className="text-xs text-gray-500 ml-2">
                              Created {new Date(module.createdAt!).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        <Button size="sm" variant="outline">
                          Edit
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="bg-primary bg-opacity-10 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Employee Management</h3>
              <p className="text-sm text-gray-600 mb-4">
                Organize your workforce into specialized training groups
              </p>
              <Button variant="outline" size="sm">Learn More</Button>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="bg-secondary bg-opacity-10 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <GraduationCap className="h-6 w-6 text-secondary" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Custom Training</h3>
              <p className="text-sm text-gray-600 mb-4">
                Create job-specific and onboarding training programs
              </p>
              <Button variant="outline" size="sm">Learn More</Button>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <div className="bg-accent bg-opacity-10 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <Settings className="h-6 w-6 text-accent" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Progress Tracking</h3>
              <p className="text-sm text-gray-600 mb-4">
                Monitor employee progress and completion rates
              </p>
              <Button variant="outline" size="sm">Learn More</Button>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
