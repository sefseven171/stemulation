import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { User, LinkedinIcon, Briefcase, Edit, Save, X, ExternalLink } from "lucide-react";
import { SiIndeed } from "react-icons/si";

export default function Profile() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [linkedinUrl, setLinkedinUrl] = useState("");
  const [indeedUrl, setIndeedUrl] = useState("");

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  useEffect(() => {
    if (user) {
      setLinkedinUrl(user.linkedinProfileUrl || "");
      setIndeedUrl(user.indeedProfileUrl || "");
    }
  }, [user]);

  const updateProfilesMutation = useMutation({
    mutationFn: async (profiles: { linkedinProfileUrl: string; indeedProfileUrl: string }) => {
      await apiRequest("PUT", "/api/user/profiles", profiles);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setIsEditing(false);
      toast({
        title: "Success",
        description: "Profile connections updated successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update profile connections. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    updateProfilesMutation.mutate({
      linkedinProfileUrl: linkedinUrl,
      indeedProfileUrl: indeedUrl,
    });
  };

  const handleCancel = () => {
    setLinkedinUrl(user?.linkedinProfileUrl || "");
    setIndeedUrl(user?.indeedProfileUrl || "");
    setIsEditing(false);
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Profile Settings</h1>
          <p className="text-lg text-gray-600">Manage your professional profile and connections</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Info */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="h-5 w-5 mr-2" />
                  Basic Information
                </CardTitle>
                <CardDescription>
                  Your account information from authentication
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-4">
                  {user?.profileImageUrl && (
                    <img 
                      src={user.profileImageUrl} 
                      alt="Profile" 
                      className="w-16 h-16 rounded-full object-cover"
                    />
                  )}
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">
                      {user?.firstName} {user?.lastName}
                    </h3>
                    <p className="text-gray-600">{user?.email}</p>
                    {user?.tradeSpecialty && (
                      <Badge variant="outline" className="mt-1">
                        {user.tradeSpecialty}
                      </Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Professional Profiles */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="flex items-center">
                      <Briefcase className="h-5 w-5 mr-2" />
                      Professional Profiles
                    </CardTitle>
                    <CardDescription>
                      Connect your LinkedIn and Indeed profiles to enhance your professional presence
                    </CardDescription>
                  </div>
                  {!isEditing ? (
                    <Button onClick={() => setIsEditing(true)} variant="outline">
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                  ) : (
                    <div className="flex space-x-2">
                      <Button 
                        onClick={handleSave} 
                        disabled={updateProfilesMutation.isPending}
                        size="sm"
                      >
                        <Save className="h-4 w-4 mr-2" />
                        {updateProfilesMutation.isPending ? "Saving..." : "Save"}
                      </Button>
                      <Button onClick={handleCancel} variant="outline" size="sm">
                        <X className="h-4 w-4 mr-2" />
                        Cancel
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* LinkedIn */}
                <div>
                  <Label htmlFor="linkedin" className="flex items-center mb-2">
                    <LinkedinIcon className="h-4 w-4 mr-2 text-blue-600" />
                    LinkedIn Profile
                  </Label>
                  {isEditing ? (
                    <Input
                      id="linkedin"
                      value={linkedinUrl}
                      onChange={(e) => setLinkedinUrl(e.target.value)}
                      placeholder="https://linkedin.com/in/your-profile"
                      className="w-full"
                    />
                  ) : (
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                      {user?.linkedinProfileUrl ? (
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-700 truncate flex-1">
                            {user.linkedinProfileUrl}
                          </span>
                          <a 
                            href={user.linkedinProfileUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-700"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </div>
                      ) : (
                        <span className="text-sm text-gray-500">Not connected</span>
                      )}
                    </div>
                  )}
                </div>

                {/* Indeed */}
                <div>
                  <Label htmlFor="indeed" className="flex items-center mb-2">
                    <SiIndeed className="h-4 w-4 mr-2 text-blue-800" />
                    Indeed Profile
                  </Label>
                  {isEditing ? (
                    <Input
                      id="indeed"
                      value={indeedUrl}
                      onChange={(e) => setIndeedUrl(e.target.value)}
                      placeholder="https://profile.indeed.com/p/your-profile-id"
                      className="w-full"
                    />
                  ) : (
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                      {user?.indeedProfileUrl ? (
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-700 truncate flex-1">
                            {user.indeedProfileUrl}
                          </span>
                          <a 
                            href={user.indeedProfileUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-700"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </div>
                      ) : (
                        <span className="text-sm text-gray-500">Not connected</span>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Profile Benefits</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div>
                  <h4 className="font-medium text-gray-900">Enhanced Visibility</h4>
                  <p className="text-gray-600">Connected profiles help employers find you more easily</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Professional Credibility</h4>
                  <p className="text-gray-600">Showcase your complete professional presence</p>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Better Matching</h4>
                  <p className="text-gray-600">Improved job recommendations based on your profiles</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Privacy Note</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Your profile URLs are only used to enhance your professional presence on this platform. 
                  We do not access or store data from your external accounts.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}