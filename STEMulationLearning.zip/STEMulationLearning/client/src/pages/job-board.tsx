import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, MapPin, Building, DollarSign, Clock, Bell, Users } from "lucide-react";
import type { JobPosting } from "@shared/schema";

const tradeCategories = [
  { value: "plumbing", label: "Plumbing" },
  { value: "mechanical", label: "Mechanical" },
  { value: "hvac", label: "HVAC" },
  { value: "electrical", label: "Electrical" },
  { value: "carpentry", label: "Carpentry" },
  { value: "energy-automation", label: "Energy Building Automation" },
];

export default function JobBoard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [isPostJobOpen, setIsPostJobOpen] = useState(false);
  const [isCreateAlertOpen, setIsCreateAlertOpen] = useState(false);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: jobPostings, isLoading: jobsLoading } = useQuery({
    queryKey: ["/api/job-postings", selectedCategory],
    enabled: !!isAuthenticated,
  });

  const postJobMutation = useMutation({
    mutationFn: async (jobData: any) => {
      await apiRequest("POST", "/api/job-postings", jobData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/job-postings"] });
      setIsPostJobOpen(false);
      toast({
        title: "Success",
        description: "Job posting created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create job posting. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createAlertMutation = useMutation({
    mutationFn: async (alertData: any) => {
      await apiRequest("POST", "/api/job-alerts", alertData);
    },
    onSuccess: () => {
      setIsCreateAlertOpen(false);
      toast({
        title: "Success",
        description: "Job alert created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create job alert. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handlePostJob = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const jobData = {
      title: formData.get("title") as string,
      company: formData.get("company") as string,
      location: formData.get("location") as string,
      description: formData.get("description") as string,
      requirements: formData.get("requirements") as string,
      salary: formData.get("salary") as string,
      tradeCategory: formData.get("tradeCategory") as string,
    };
    postJobMutation.mutate(jobData);
  };

  const handleCreateAlert = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const alertData = {
      tradeCategory: formData.get("tradeCategory") as string,
      location: formData.get("location") as string,
      keywords: formData.get("keywords") as string,
    };
    createAlertMutation.mutate(alertData);
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Job Board</h1>
            <p className="text-lg text-gray-600">Find your next opportunity in the skilled trades</p>
          </div>
          
          <div className="flex space-x-4">
            <Dialog open={isCreateAlertOpen} onOpenChange={setIsCreateAlertOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Bell className="h-4 w-4 mr-2" />
                  Create Alert
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Job Alert</DialogTitle>
                  <DialogDescription>
                    Get notified when new jobs match your criteria
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleCreateAlert} className="space-y-4">
                  <div>
                    <Label htmlFor="alert-category">Trade Category</Label>
                    <Select name="tradeCategory" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a trade category" />
                      </SelectTrigger>
                      <SelectContent>
                        {tradeCategories.map((category) => (
                          <SelectItem key={category.value} value={category.value}>
                            {category.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="alert-location">Location (optional)</Label>
                    <Input name="location" placeholder="e.g., Seattle, WA" />
                  </div>
                  <div>
                    <Label htmlFor="alert-keywords">Keywords (optional)</Label>
                    <Input name="keywords" placeholder="e.g., senior, apprentice, certified" />
                  </div>
                  <Button type="submit" disabled={createAlertMutation.isPending}>
                    {createAlertMutation.isPending ? "Creating..." : "Create Alert"}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>

            <Dialog open={isPostJobOpen} onOpenChange={setIsPostJobOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Post Job
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Post a New Job</DialogTitle>
                  <DialogDescription>
                    Create a job posting to find qualified candidates
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handlePostJob} className="space-y-4">
                  <div>
                    <Label htmlFor="title">Job Title</Label>
                    <Input name="title" required placeholder="e.g., Senior HVAC Technician" />
                  </div>
                  <div>
                    <Label htmlFor="company">Company</Label>
                    <Input name="company" required placeholder="e.g., BuildRight Construction" />
                  </div>
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Input name="location" required placeholder="e.g., Seattle, WA" />
                  </div>
                  <div>
                    <Label htmlFor="salary">Salary Range</Label>
                    <Input name="salary" placeholder="e.g., $65,000 - $85,000" />
                  </div>
                  <div>
                    <Label htmlFor="tradeCategory">Trade Category</Label>
                    <Select name="tradeCategory" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a trade category" />
                      </SelectTrigger>
                      <SelectContent>
                        {tradeCategories.map((category) => (
                          <SelectItem key={category.value} value={category.value}>
                            {category.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="description">Job Description</Label>
                    <Textarea 
                      name="description" 
                      required 
                      rows={4}
                      placeholder="Describe the role, responsibilities, and what you're looking for..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="requirements">Requirements</Label>
                    <Textarea 
                      name="requirements" 
                      rows={3}
                      placeholder="List the required skills, experience, certifications..."
                    />
                  </div>
                  <Button type="submit" disabled={postJobMutation.isPending}>
                    {postJobMutation.isPending ? "Posting..." : "Post Job"}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-3">
            <div className="mb-6">
              <Label htmlFor="category-filter">Filter by Category</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="All categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All categories</SelectItem>
                  {tradeCategories.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-6">
              {jobsLoading ? (
                <div className="text-center py-8">Loading job postings...</div>
              ) : !jobPostings || jobPostings.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center">
                    <div className="text-gray-500">
                      <Briefcase className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <h3 className="text-lg font-medium mb-2">No job postings found</h3>
                      <p className="text-sm">Be the first to post a job or try adjusting your filters.</p>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                jobPostings.map((job: JobPosting) => (
                  <Card key={job.id} className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-xl">{job.title}</CardTitle>
                          <CardDescription className="flex items-center mt-2">
                            <Building className="h-4 w-4 mr-1" />
                            {job.company}
                            <MapPin className="h-4 w-4 ml-4 mr-1" />
                            {job.location}
                          </CardDescription>
                        </div>
                        <Badge variant={job.status === "open" ? "default" : "secondary"}>
                          {job.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 mb-4">{job.description}</p>
                      
                      {job.requirements && (
                        <div className="mb-4">
                          <h4 className="font-medium text-gray-900 mb-2">Requirements:</h4>
                          <p className="text-sm text-gray-600">{job.requirements}</p>
                        </div>
                      )}
                      
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          {job.salary && (
                            <span className="flex items-center">
                              <DollarSign className="h-4 w-4 mr-1" />
                              {job.salary}
                            </span>
                          )}
                          <Badge variant="outline">{job.tradeCategory}</Badge>
                          <span className="flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            {new Date(job.createdAt!).toLocaleDateString()}
                          </span>
                        </div>
                        <Button>Apply Now</Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="h-5 w-5 mr-2" />
                  Member Connections
                </CardTitle>
                <CardDescription>
                  Connect with other professionals in your field
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline">
                  <Users className="h-4 w-4 mr-2" />
                  Find Members
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Job Search Tips</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div>
                  <h4 className="font-medium">Optimize your profile</h4>
                  <p className="text-gray-600">Complete your video portfolio to stand out</p>
                </div>
                <div>
                  <h4 className="font-medium">Set up alerts</h4>
                  <p className="text-gray-600">Get notified when matching jobs are posted</p>
                </div>
                <div>
                  <h4 className="font-medium">Network actively</h4>
                  <p className="text-gray-600">Connect with other professionals and employers</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
