import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Play, Upload, Clock, User, Trash2 } from "lucide-react";
import type { VideoPortfolio } from "@shared/schema";

const tradeCategories = [
  { value: "plumbing", label: "Plumbing" },
  { value: "mechanical", label: "Mechanical" },
  { value: "hvac", label: "HVAC" },
  { value: "electrical", label: "Electrical" },
  { value: "carpentry", label: "Carpentry" },
  { value: "energy-automation", label: "Energy Building Automation" },
];

export default function VideoPortfolio() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [isUploadOpen, setIsUploadOpen] = useState(false);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: allVideos, isLoading: allVideosLoading } = useQuery({
    queryKey: ["/api/video-portfolios", selectedCategory],
    enabled: !!isAuthenticated,
  });

  const { data: myVideos, isLoading: myVideosLoading } = useQuery({
    queryKey: ["/api/my-videos"],
    enabled: !!isAuthenticated,
  });

  const uploadVideoMutation = useMutation({
    mutationFn: async (videoData: any) => {
      await apiRequest("POST", "/api/video-portfolios", videoData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/video-portfolios"] });
      queryClient.invalidateQueries({ queryKey: ["/api/my-videos"] });
      setIsUploadOpen(false);
      toast({
        title: "Success",
        description: "Video uploaded successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to upload video. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteVideoMutation = useMutation({
    mutationFn: async (videoId: number) => {
      await apiRequest("DELETE", `/api/video-portfolios/${videoId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/video-portfolios"] });
      queryClient.invalidateQueries({ queryKey: ["/api/my-videos"] });
      toast({
        title: "Success",
        description: "Video deleted successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete video. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleUploadVideo = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const videoData = {
      title: formData.get("title") as string,
      description: formData.get("description") as string,
      videoUrl: formData.get("videoUrl") as string,
      duration: formData.get("duration") as string,
      tradeCategory: formData.get("tradeCategory") as string,
    };
    uploadVideoMutation.mutate(videoData);
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Video Portfolio</h1>
            <p className="text-lg text-gray-600">Showcase your skills and work experience</p>
          </div>
          
          <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
            <DialogTrigger asChild>
              <Button>
                <Upload className="h-4 w-4 mr-2" />
                Upload Video
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Upload Your Work</DialogTitle>
                <DialogDescription>
                  Share your expertise and build your professional reputation
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleUploadVideo} className="space-y-4">
                <div>
                  <Label htmlFor="title">Video Title</Label>
                  <Input name="title" required placeholder="e.g., Commercial Electrical Panel Installation" />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea 
                    name="description" 
                    rows={3}
                    placeholder="Describe what's shown in the video, techniques used, etc..."
                  />
                </div>
                <div>
                  <Label htmlFor="videoUrl">Video URL</Label>
                  <Input name="videoUrl" required placeholder="https://youtube.com/watch?v=..." />
                  <p className="text-xs text-gray-500 mt-1">
                    Paste a link to your video on YouTube, Vimeo, or other platform
                  </p>
                </div>
                <div>
                  <Label htmlFor="duration">Duration</Label>
                  <Input name="duration" placeholder="e.g., 12:34" />
                </div>
                <div>
                  <Label htmlFor="tradeCategory">Trade Category</Label>
                  <Select name="tradeCategory" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a trade category" />
                    </SelectTrigger>
                    <SelectContent>
                      {tradeCategories.map((category) => (
                        <SelectItem key={category.value} value={category.value}>
                          {category.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" disabled={uploadVideoMutation.isPending}>
                  {uploadVideoMutation.isPending ? "Uploading..." : "Upload Video"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-3">
            <div className="mb-6">
              <Label htmlFor="category-filter">Filter by Category</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="All categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All categories</SelectItem>
                  {tradeCategories.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {allVideosLoading ? (
                <div className="col-span-2 text-center py-8">Loading videos...</div>
              ) : !allVideos || allVideos.length === 0 ? (
                <Card className="col-span-2">
                  <CardContent className="py-8 text-center">
                    <div className="text-gray-500">
                      <Play className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <h3 className="text-lg font-medium mb-2">No videos found</h3>
                      <p className="text-sm">Be the first to share your work or try adjusting your filters.</p>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                allVideos.map((video: VideoPortfolio) => (
                  <Card key={video.id} className="overflow-hidden hover:shadow-md transition-shadow">
                    <div className="aspect-video bg-gray-200 flex items-center justify-center">
                      <Play className="h-12 w-12 text-primary" />
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-gray-900 mb-2">{video.title}</h3>
                      <p className="text-sm text-gray-600 mb-2">
                        <User className="h-3 w-3 inline mr-1" />
                        by Professional
                      </p>
                      {video.description && (
                        <p className="text-sm text-gray-700 mb-3 line-clamp-2">{video.description}</p>
                      )}
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-2">
                          {video.duration && (
                            <span className="text-xs text-gray-500 flex items-center">
                              <Clock className="h-3 w-3 mr-1" />
                              {video.duration}
                            </span>
                          )}
                          <Badge variant="outline" className="text-xs">
                            {video.tradeCategory}
                          </Badge>
                        </div>
                        <Button size="sm" variant="outline">
                          View Project
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>My Videos</CardTitle>
                <CardDescription>
                  Manage your uploaded content
                </CardDescription>
              </CardHeader>
              <CardContent>
                {myVideosLoading ? (
                  <div className="text-center py-4">Loading...</div>
                ) : !myVideos || myVideos.length === 0 ? (
                  <div className="text-center py-4 text-gray-500">
                    <p className="text-sm">No videos uploaded yet</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {myVideos.slice(0, 3).map((video: VideoPortfolio) => (
                      <div key={video.id} className="flex justify-between items-start p-2 bg-gray-50 rounded">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">{video.title}</p>
                          <p className="text-xs text-gray-500">{video.tradeCategory}</p>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteVideoMutation.mutate(video.id)}
                          disabled={deleteVideoMutation.isPending}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Upload Tips</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div>
                  <h4 className="font-medium">Show your process</h4>
                  <p className="text-gray-600">Document your work from start to finish</p>
                </div>
                <div>
                  <h4 className="font-medium">Good lighting</h4>
                  <p className="text-gray-600">Ensure your work area is well-lit</p>
                </div>
                <div>
                  <h4 className="font-medium">Clear narration</h4>
                  <p className="text-gray-600">Explain what you're doing and why</p>
                </div>
                <div>
                  <h4 className="font-medium">Safety first</h4>
                  <p className="text-gray-600">Always demonstrate proper safety procedures</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
