import { useState, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { Upload, Video, Youtube, CheckCircle, AlertCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { ButtonLoader } from "@/components/ui/loading-spinner";
import TradeSkillBadge from "@/components/trade-skill-badge";

interface VideoUploadProps {
  onUploadComplete?: (video: any) => void;
}

const tradeCategories = [
  "Plumbing",
  "Mechanical", 
  "HVAC",
  "Electrical",
  "Carpentry",
  "Energy Building Automation"
];

export default function VideoUpload({ onUploadComplete }: VideoUploadProps) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    tradeCategory: "",
    skillsShowcased: "",
    isPublic: true
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'processing' | 'completed' | 'error'>('idle');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('video/')) {
      toast({
        title: "Invalid File Type",
        description: "Please select a video file.",
        variant: "destructive"
      });
      return;
    }

    // Validate file size (500MB limit)
    if (file.size > 500 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Video files must be under 500MB.",
        variant: "destructive"
      });
      return;
    }

    setSelectedFile(file);
    setUploadStatus('idle');
  };

  const handleInputChange = (field: keyof typeof formData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleUpload = async () => {
    if (!selectedFile || !formData.title || !formData.tradeCategory) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields and select a video file.",
        variant: "destructive"
      });
      return;
    }

    setIsUploading(true);
    setUploadStatus('uploading');
    setUploadProgress(0);

    try {
      const uploadFormData = new FormData();
      uploadFormData.append('video', selectedFile);
      uploadFormData.append('title', formData.title);
      uploadFormData.append('description', formData.description);
      uploadFormData.append('tradeCategory', formData.tradeCategory);
      uploadFormData.append('skillsShowcased', formData.skillsShowcased);
      uploadFormData.append('isPublic', formData.isPublic.toString());

      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      const response = await fetch('/api/video-portfolios/upload', {
        method: 'POST',
        body: uploadFormData,
      });

      clearInterval(progressInterval);

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Upload failed');
      }

      const result = await response.json();
      
      setUploadProgress(100);
      setUploadStatus('completed');

      toast({
        title: "Upload Successful",
        description: result.youtubeVideoId 
          ? "Video uploaded to both STEMulation and YouTube!"
          : "Video uploaded to STEMulation! YouTube integration not configured.",
      });

      // Reset form
      setFormData({
        title: "",
        description: "",
        tradeCategory: "",
        skillsShowcased: "",
        isPublic: true
      });
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }

      onUploadComplete?.(result);

    } catch (error: any) {
      console.error('Upload error:', error);
      setUploadStatus('error');
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload video. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const getStatusIcon = () => {
    switch (uploadStatus) {
      case 'uploading':
        return <Upload className="h-5 w-5 animate-pulse text-blue-500" />;
      case 'processing':
        return <Video className="h-5 w-5 animate-pulse text-yellow-500" />;
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Upload className="h-5 w-5" />;
    }
  };

  const getStatusText = () => {
    switch (uploadStatus) {
      case 'uploading':
        return 'Uploading video...';
      case 'processing':
        return 'Processing video...';
      case 'completed':
        return 'Upload completed successfully!';
      case 'error':
        return 'Upload failed. Please try again.';
      default:
        return 'Ready to upload';
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Video className="h-6 w-6 mr-2" />
          Upload Video Portfolio
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* File Upload */}
        <div>
          <Label htmlFor="video-file">Video File *</Label>
          <Input
            id="video-file"
            type="file"
            accept="video/*"
            ref={fileInputRef}
            onChange={handleFileSelect}
            disabled={isUploading}
            className="mt-1"
          />
          {selectedFile && (
            <div className="mt-2 text-sm text-gray-600">
              Selected: {selectedFile.name} ({(selectedFile.size / (1024 * 1024)).toFixed(1)} MB)
            </div>
          )}
        </div>

        {/* Video Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              placeholder="Enter video title"
              value={formData.title}
              onChange={(e) => handleInputChange("title", e.target.value)}
              disabled={isUploading}
            />
          </div>
          <div>
            <Label htmlFor="tradeCategory">Trade Category *</Label>
            <Select 
              value={formData.tradeCategory} 
              onValueChange={(value) => handleInputChange("tradeCategory", value)}
              disabled={isUploading}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {tradeCategories.map((category) => (
                  <SelectItem key={category} value={category}>
                    <div className="flex items-center space-x-2">
                      <TradeSkillBadge trade={category} size="sm" />
                      <span>{category}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            placeholder="Describe what skills and techniques you're demonstrating..."
            value={formData.description}
            onChange={(e) => handleInputChange("description", e.target.value)}
            disabled={isUploading}
            className="min-h-[100px]"
          />
        </div>

        <div>
          <Label htmlFor="skills">Skills Showcased</Label>
          <Input
            id="skills"
            placeholder="e.g., pipe fitting, electrical wiring, welding (comma-separated)"
            value={formData.skillsShowcased}
            onChange={(e) => handleInputChange("skillsShowcased", e.target.value)}
            disabled={isUploading}
          />
        </div>

        {/* Visibility Settings */}
        <div className="flex items-center justify-between p-4 border rounded-lg">
          <div>
            <Label htmlFor="isPublic" className="text-base font-medium">
              Public Visibility
            </Label>
            <p className="text-sm text-gray-600">
              Make this video visible to all platform users
            </p>
          </div>
          <Switch
            id="isPublic"
            checked={formData.isPublic}
            onCheckedChange={(checked) => handleInputChange("isPublic", checked)}
            disabled={isUploading}
          />
        </div>

        {/* YouTube Integration Notice */}
        <div className="flex items-start space-x-3 p-4 bg-blue-50 rounded-lg">
          <Youtube className="h-5 w-5 text-red-500 mt-0.5" />
          <div>
            <p className="text-sm font-medium">YouTube Integration</p>
            <p className="text-sm text-gray-600">
              Videos are automatically uploaded to your YouTube channel if you've connected your account.
              They'll also be available locally on STEMulation Learning.
            </p>
          </div>
        </div>

        {/* Upload Progress */}
        {isUploading && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Upload Progress</span>
              <span className="text-sm text-gray-600">{uploadProgress}%</span>
            </div>
            <Progress value={uploadProgress} className="w-full" />
          </div>
        )}

        {/* Status */}
        <div className="flex items-center space-x-2 text-sm">
          {getStatusIcon()}
          <span>{getStatusText()}</span>
        </div>

        {/* Upload Button */}
        <Button 
          onClick={handleUpload} 
          disabled={isUploading || !selectedFile || !formData.title || !formData.tradeCategory}
          className="w-full"
        >
          {isUploading && <ButtonLoader />}
          {isUploading ? "Uploading..." : "Upload Video"}
        </Button>
      </CardContent>
    </Card>
  );
}