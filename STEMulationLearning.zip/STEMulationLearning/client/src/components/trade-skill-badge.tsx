import { Badge } from "@/components/ui/badge";
import { getTradeBackground, getTradeColors } from "@/lib/trade-backgrounds";
import { cn } from "@/lib/utils";

interface TradeSkillBadgeProps {
  trade: string;
  size?: "sm" | "md" | "lg";
  variant?: "default" | "outline" | "card";
  className?: string;
}

export default function TradeSkillBadge({ 
  trade, 
  size = "md", 
  variant = "default",
  className 
}: TradeSkillBadgeProps) {
  const colors = getTradeColors(trade);
  const backgroundImage = getTradeBackground(trade);

  const sizeClasses = {
    sm: "px-2 py-1 text-xs",
    md: "px-3 py-1.5 text-sm",
    lg: "px-4 py-2 text-base"
  };

  if (variant === "card") {
    return (
      <div 
        className={cn(
          "relative overflow-hidden rounded-lg border bg-card text-card-foreground shadow-sm",
          "min-h-[120px] p-4 flex flex-col justify-end",
          className
        )}
        style={{
          backgroundImage: `url(${backgroundImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
        <div className="relative z-10">
          <h3 className="font-semibold text-white text-lg mb-2">{trade}</h3>
          <div 
            className={cn(
              "inline-flex items-center rounded-md px-2.5 py-0.5 text-xs font-medium",
              "bg-white/90 text-gray-900"
            )}
          >
            {trade}
          </div>
        </div>
      </div>
    );
  }

  if (variant === "outline") {
    return (
      <Badge 
        variant="outline"
        className={cn(
          sizeClasses[size],
          "border-2 font-medium transition-all hover:shadow-md",
          className
        )}
        style={{
          borderColor: colors.primary,
          color: colors.primary,
          backgroundColor: 'transparent'
        }}
      >
        {trade}
      </Badge>
    );
  }

  return (
    <Badge 
      className={cn(
        sizeClasses[size],
        "font-medium transition-all hover:shadow-md hover:scale-105",
        className
      )}
      style={{
        backgroundColor: colors.primary,
        color: 'white',
        backgroundImage: `linear-gradient(45deg, ${colors.primary}, ${colors.secondary})`
      }}
    >
      {trade}
    </Badge>
  );
}