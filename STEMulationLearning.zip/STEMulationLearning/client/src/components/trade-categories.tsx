import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const tradeCategories = [
  {
    name: "Plumbing",
    description: "Master water systems, pipe installation, and repair techniques",
    icon: "fas fa-wrench",
    colorClass: "bg-primary bg-opacity-10",
    iconColorClass: "text-primary",
  },
  {
    name: "Mechanical",
    description: "Mechanical systems, equipment maintenance, and troubleshooting",
    icon: "fas fa-cogs",
    colorClass: "bg-secondary bg-opacity-10",
    iconColorClass: "text-secondary",
  },
  {
    name: "HVAC",
    description: "Heating, ventilation, and air conditioning systems expertise",
    icon: "fas fa-thermometer-half",
    colorClass: "bg-accent bg-opacity-10",
    iconColorClass: "text-accent",
  },
  {
    name: "Electrical",
    description: "Electrical systems, wiring, and power distribution",
    icon: "fas fa-bolt",
    colorClass: "bg-yellow-500 bg-opacity-10",
    iconColorClass: "text-yellow-600",
  },
  {
    name: "Carpentry",
    description: "Woodworking, framing, and construction techniques",
    icon: "fas fa-hammer",
    colorClass: "bg-amber-500 bg-opacity-10",
    iconColorClass: "text-amber-600",
  },
  {
    name: "Energy Building Automation",
    description: "Smart building systems and energy management",
    icon: "fas fa-microchip",
    colorClass: "bg-green-500 bg-opacity-10",
    iconColorClass: "text-green-600",
  },
];

export default function TradeCategories() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">
            Skilled Trade Specializations
          </h3>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Choose your path and master the skills that build our world
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {tradeCategories.map((category, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow border border-gray-200">
              <CardContent className="p-6 text-center">
                <div className={`${category.colorClass} rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4`}>
                  <i className={`${category.icon} text-2xl ${category.iconColorClass}`}></i>
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  {category.name}
                </h4>
                <p className="text-gray-600 mb-4">
                  {category.description}
                </p>
                <Button 
                  variant="ghost" 
                  className="text-primary hover:text-blue-700 font-medium"
                  onClick={() => window.location.href = "/api/login"}
                >
                  Learn More <i className="fas fa-arrow-right ml-1"></i>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
