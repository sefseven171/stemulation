import { Button } from "@/components/ui/button";

export default function HeroSection() {
  return (
    <section className="bg-gradient-to-r from-primary to-blue-600 text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Master the Trades, Build Your Future
          </h2>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto font-light">
            Professional vocational training for construction skilled trades. Connect with employers, 
            showcase your skills, and advance your career.
          </p>
          <Button 
            size="lg"
            className="bg-secondary hover:bg-orange-600 text-white px-8 py-4 text-lg font-semibold shadow-lg"
            onClick={() => window.location.href = "/api/login"}
          >
            <i className="fas fa-tools mr-2"></i>
            Enter the Workshop
          </Button>
        </div>
      </div>
    </section>
  );
}
