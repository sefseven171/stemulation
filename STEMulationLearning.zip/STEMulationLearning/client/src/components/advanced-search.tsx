import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, Filter, X } from "lucide-react";
import TradeSkillBadge from "@/components/trade-skill-badge";

interface SearchFilters {
  keywords: string;
  location: string;
  tradeCategory: string;
  salaryMin: string;
  salaryMax: string;
  experienceLevel: string;
  employmentType: string;
}

interface AdvancedSearchProps {
  onSearch: (filters: SearchFilters) => void;
  onClear: () => void;
  isLoading?: boolean;
}

const tradeCategories = [
  "Plumbing",
  "Mechanical", 
  "HVAC",
  "Electrical",
  "Carpentry",
  "Energy Building Automation"
];

const experienceLevels = [
  "entry",
  "intermediate", 
  "advanced",
  "expert"
];

const employmentTypes = [
  "full-time",
  "part-time",
  "contract",
  "temporary"
];

export default function AdvancedSearch({ onSearch, onClear, isLoading }: AdvancedSearchProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    keywords: "",
    location: "",
    tradeCategory: "",
    salaryMin: "",
    salaryMax: "",
    experienceLevel: "",
    employmentType: ""
  });

  const [showAdvanced, setShowAdvanced] = useState(false);

  const handleInputChange = (field: keyof SearchFilters, value: string) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const handleSearch = () => {
    onSearch(filters);
  };

  const handleClear = () => {
    setFilters({
      keywords: "",
      location: "",
      tradeCategory: "",
      salaryMin: "",
      salaryMax: "",
      experienceLevel: "",
      employmentType: ""
    });
    onClear();
  };

  const hasActiveFilters = Object.values(filters).some(value => value !== "");

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center">
            <Search className="h-5 w-5 mr-2" />
            Search Jobs
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowAdvanced(!showAdvanced)}
          >
            <Filter className="h-4 w-4 mr-2" />
            {showAdvanced ? "Simple Search" : "Advanced Search"}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Basic Search */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="keywords">Keywords</Label>
            <Input
              id="keywords"
              placeholder="Job title, skills, company..."
              value={filters.keywords}
              onChange={(e) => handleInputChange("keywords", e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              placeholder="City, state, or remote"
              value={filters.location}
              onChange={(e) => handleInputChange("location", e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="tradeCategory">Trade Category</Label>
            <Select value={filters.tradeCategory} onValueChange={(value) => handleInputChange("tradeCategory", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select trade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Trades</SelectItem>
                {tradeCategories.map((category) => (
                  <SelectItem key={category} value={category}>
                    <div className="flex items-center space-x-2">
                      <TradeSkillBadge trade={category} size="sm" />
                      <span>{category}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Advanced Filters */}
        {showAdvanced && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t">
            <div>
              <Label htmlFor="salaryMin">Min Salary ($)</Label>
              <Input
                id="salaryMin"
                type="number"
                placeholder="50000"
                value={filters.salaryMin}
                onChange={(e) => handleInputChange("salaryMin", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="salaryMax">Max Salary ($)</Label>
              <Input
                id="salaryMax"
                type="number"
                placeholder="100000"
                value={filters.salaryMax}
                onChange={(e) => handleInputChange("salaryMax", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="experienceLevel">Experience Level</Label>
              <Select value={filters.experienceLevel} onValueChange={(value) => handleInputChange("experienceLevel", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Any level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Any Level</SelectItem>
                  {experienceLevels.map((level) => (
                    <SelectItem key={level} value={level}>
                      {level.charAt(0).toUpperCase() + level.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="employmentType">Employment Type</Label>
              <Select value={filters.employmentType} onValueChange={(value) => handleInputChange("employmentType", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Any type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Any Type</SelectItem>
                  {employmentTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex justify-between items-center pt-4">
          <div className="flex space-x-2">
            <Button onClick={handleSearch} disabled={isLoading}>
              <Search className="h-4 w-4 mr-2" />
              {isLoading ? "Searching..." : "Search Jobs"}
            </Button>
            {hasActiveFilters && (
              <Button variant="outline" onClick={handleClear}>
                <X className="h-4 w-4 mr-2" />
                Clear Filters
              </Button>
            )}
          </div>
          {hasActiveFilters && (
            <div className="text-sm text-gray-500">
              Active filters applied
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}