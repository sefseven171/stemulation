import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { LinkedinIcon, ExternalLink, Plus } from "lucide-react";
import { SiIndeed } from "react-icons/si";
import type { User } from "@shared/schema";

interface ProfileConnectionsProps {
  user: User;
}

export default function ProfileConnections({ user }: ProfileConnectionsProps) {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [linkedinUrl, setLinkedinUrl] = useState(user?.linkedinProfileUrl || "");
  const [indeedUrl, setIndeedUrl] = useState(user?.indeedProfileUrl || "");

  const updateProfilesMutation = useMutation({
    mutationFn: async (profiles: { linkedinProfileUrl: string; indeedProfileUrl: string }) => {
      await apiRequest("PUT", "/api/user/profiles", profiles);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setIsDialogOpen(false);
      toast({
        title: "Success",
        description: "Profile connections updated successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update profile connections. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfilesMutation.mutate({
      linkedinProfileUrl: linkedinUrl,
      indeedProfileUrl: indeedUrl,
    });
  };

  const hasConnections = user?.linkedinProfileUrl || user?.indeedProfileUrl;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Professional Profiles</span>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Plus className="h-4 w-4 mr-2" />
                {hasConnections ? "Update" : "Connect"}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Connect Professional Profiles</DialogTitle>
                <DialogDescription>
                  Link your LinkedIn and Indeed profiles to enhance your professional presence
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSave} className="space-y-4">
                <div>
                  <Label htmlFor="linkedin" className="flex items-center mb-2">
                    <LinkedinIcon className="h-4 w-4 mr-2 text-blue-600" />
                    LinkedIn Profile URL
                  </Label>
                  <Input
                    id="linkedin"
                    value={linkedinUrl}
                    onChange={(e) => setLinkedinUrl(e.target.value)}
                    placeholder="https://linkedin.com/in/your-profile"
                  />
                </div>
                <div>
                  <Label htmlFor="indeed" className="flex items-center mb-2">
                    <SiIndeed className="h-4 w-4 mr-2 text-blue-800" />
                    Indeed Profile URL
                  </Label>
                  <Input
                    id="indeed"
                    value={indeedUrl}
                    onChange={(e) => setIndeedUrl(e.target.value)}
                    placeholder="https://profile.indeed.com/p/your-profile-id"
                  />
                </div>
                <Button type="submit" disabled={updateProfilesMutation.isPending} className="w-full">
                  {updateProfilesMutation.isPending ? "Saving..." : "Save Connections"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </CardTitle>
        <CardDescription>
          Connect your profiles to increase visibility to employers
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {user?.linkedinProfileUrl ? (
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <LinkedinIcon className="h-5 w-5 text-blue-600" />
                <span className="text-sm font-medium text-gray-900">LinkedIn Connected</span>
              </div>
              <a 
                href={user.linkedinProfileUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 hover:text-blue-700"
              >
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
          ) : (
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <LinkedinIcon className="h-5 w-5 text-gray-400" />
                <span className="text-sm text-gray-500">LinkedIn not connected</span>
              </div>
            </div>
          )}

          {user?.indeedProfileUrl ? (
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <SiIndeed className="h-5 w-5 text-blue-800" />
                <span className="text-sm font-medium text-gray-900">Indeed Connected</span>
              </div>
              <a 
                href={user.indeedProfileUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 hover:text-blue-700"
              >
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
          ) : (
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <SiIndeed className="h-5 w-5 text-gray-400" />
                <span className="text-sm text-gray-500">Indeed not connected</span>
              </div>
            </div>
          )}
        </div>

        {!hasConnections && (
          <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-yellow-800">
              Connect your professional profiles to increase your visibility to employers and get better job matches.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}