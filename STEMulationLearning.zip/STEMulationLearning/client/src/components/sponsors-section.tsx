import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const sponsors = [
  "DeWalt",
  "Caterpillar", 
  "Milwaukee",
  "Bosch",
  "Makita",
  "Hilti"
];

export default function SponsorsSection() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">
            Industry Partners
          </h3>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Trusted by leading construction and trade companies
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 items-center">
          {sponsors.map((sponsor, index) => (
            <div key={index} className="text-center">
              <div className="bg-gray-100 rounded-lg p-4 h-16 flex items-center justify-center mb-2">
                <span className="text-gray-500 font-semibold">{sponsor}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <h4 className="text-xl font-semibold text-gray-900 mb-4">
            Partner With Us
          </h4>
          <p className="text-gray-600 mb-6">
            Join our network of industry leaders and connect with skilled professionals
          </p>
          <Button 
            className="bg-accent text-white px-6 py-3 font-medium hover:bg-green-600"
            onClick={() => window.location.href = "/contact"}
          >
            Become a Partner
          </Button>
        </div>
      </div>
    </section>
  );
}
