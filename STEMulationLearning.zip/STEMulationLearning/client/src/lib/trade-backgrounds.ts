// Trade background mappings
export const tradeBackgrounds = {
  "Plumbing": "/src/assets/trade-backgrounds/plumbing.svg",
  "Mechanical": "/src/assets/trade-backgrounds/mechanical.svg", 
  "HVAC": "/src/assets/trade-backgrounds/hvac.svg",
  "Electrical": "/src/assets/trade-backgrounds/electrical.svg",
  "Carpentry": "/src/assets/trade-backgrounds/carpentry.svg",
  "Energy Building Automation": "/src/assets/trade-backgrounds/energy-building-automation.svg"
};

export const tradeColors = {
  "Plumbing": {
    primary: "#2563eb",
    secondary: "#3b82f6",
    accent: "#0ea5e9",
    background: "from-blue-500/10 to-blue-600/20"
  },
  "Mechanical": {
    primary: "#4b5563",
    secondary: "#6b7280", 
    accent: "#9ca3af",
    background: "from-gray-500/10 to-gray-600/20"
  },
  "HVAC": {
    primary: "#059669",
    secondary: "#10b981",
    accent: "#34d399",
    background: "from-emerald-500/10 to-emerald-600/20"
  },
  "Electrical": {
    primary: "#eab308",
    secondary: "#f59e0b",
    accent: "#fbbf24",
    background: "from-yellow-500/10 to-yellow-600/20"
  },
  "Carpentry": {
    primary: "#92400e",
    secondary: "#d97706",
    accent: "#f59e0b",
    background: "from-amber-600/10 to-amber-700/20"
  },
  "Energy Building Automation": {
    primary: "#7c3aed",
    secondary: "#8b5cf6",
    accent: "#a78bfa",
    background: "from-violet-500/10 to-violet-600/20"
  }
};

export function getTradeBackground(trade: string): string {
  return tradeBackgrounds[trade as keyof typeof tradeBackgrounds] || "";
}

export function getTradeColors(trade: string) {
  return tradeColors[trade as keyof typeof tradeColors] || tradeColors["Plumbing"];
}