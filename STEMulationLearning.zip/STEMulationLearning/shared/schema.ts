import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
  decimal,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Enhanced User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  tradeSpecialty: varchar("trade_specialty"),
  role: varchar("role").default("member"), // member, employer, admin
  linkedinProfileUrl: varchar("linkedin_profile_url"),
  indeedProfileUrl: varchar("indeed_profile_url"),
  location: varchar("location"),
  phoneNumber: varchar("phone_number"),
  experienceLevel: varchar("experience_level"), // entry, intermediate, advanced, expert
  skillTags: text("skill_tags").array(),
  profileCompletionPercentage: integer("profile_completion_percentage").default(0),
  isProfileVerified: boolean("is_profile_verified").default(false),
  youtubeChannelId: varchar("youtube_channel_id"),
  youtubeAccessToken: varchar("youtube_access_token"),
  youtubeRefreshToken: varchar("youtube_refresh_token"),
  lastLoginAt: timestamp("last_login_at"),
  rating: decimal("rating", { precision: 3, scale: 2 }).default("0.00"),
  totalRatings: integer("total_ratings").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_users_trade_specialty").on(table.tradeSpecialty),
  index("idx_users_role").on(table.role),
  index("idx_users_location").on(table.location),
  index("idx_users_experience_level").on(table.experienceLevel),
]);

// Enhanced Job postings table
export const jobPostings = pgTable("job_postings", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  company: text("company").notNull(),
  location: text("location").notNull(),
  description: text("description").notNull(),
  salary: text("salary"),
  salaryMin: integer("salary_min"),
  salaryMax: integer("salary_max"),
  requirements: text("requirements"),
  benefits: text("benefits"),
  tradeCategory: varchar("trade_category").notNull(),
  employmentType: varchar("employment_type").default("full-time"), // full-time, part-time, contract, temporary
  experienceLevel: varchar("experience_level"), // entry, mid, senior
  skillsRequired: text("skills_required").array(),
  postedBy: varchar("posted_by").notNull().references(() => users.id),
  isActive: boolean("is_active").default(true),
  applicationDeadline: timestamp("application_deadline"),
  priority: integer("priority").default(0), // for featured listings
  externalJobId: varchar("external_job_id"), // for indeed/linkedin integration
  viewCount: integer("view_count").default(0),
  applicationCount: integer("application_count").default(0),
  isUrgent: boolean("is_urgent").default(false),
  contactEmail: varchar("contact_email"),
  contactPhone: varchar("contact_phone"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_job_postings_trade_category").on(table.tradeCategory),
  index("idx_job_postings_location").on(table.location),
  index("idx_job_postings_posted_by").on(table.postedBy),
  index("idx_job_postings_is_active").on(table.isActive),
  index("idx_job_postings_created_at").on(table.createdAt),
  index("idx_job_postings_salary_min").on(table.salaryMin),
  index("idx_job_postings_experience_level").on(table.experienceLevel),
]);

// Enhanced Video portfolios table with YouTube integration
export const videoPortfolios = pgTable("video_portfolios", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  videoUrl: text("video_url").notNull(),
  youtubeVideoId: varchar("youtube_video_id"),
  thumbnailUrl: text("thumbnail_url"),
  localVideoPath: text("local_video_path"),
  tradeCategory: varchar("trade_category").notNull(),
  skillsShowcased: text("skills_showcased").array(),
  viewCount: integer("view_count").default(0),
  likeCount: integer("like_count").default(0),
  isPublic: boolean("is_public").default(true),
  uploadStatus: varchar("upload_status").default("pending"), // pending, processing, completed, failed
  duration: integer("duration"), // in seconds
  fileSize: integer("file_size"), // in bytes
  quality: varchar("quality").default("720p"), // 480p, 720p, 1080p
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_video_portfolios_user_id").on(table.userId),
  index("idx_video_portfolios_trade_category").on(table.tradeCategory),
  index("idx_video_portfolios_is_public").on(table.isPublic),
  index("idx_video_portfolios_created_at").on(table.createdAt),
]);

// Messages table for communication system
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: varchar("sender_id").notNull().references(() => users.id),
  receiverId: varchar("receiver_id").notNull().references(() => users.id),
  subject: varchar("subject"),
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false),
  messageType: varchar("message_type").default("direct"), // direct, job_inquiry, connection_request
  relatedJobId: integer("related_job_id").references(() => jobPostings.id),
  attachmentUrl: text("attachment_url"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_messages_sender_id").on(table.senderId),
  index("idx_messages_receiver_id").on(table.receiverId),
  index("idx_messages_created_at").on(table.createdAt),
  index("idx_messages_is_read").on(table.isRead),
]);

// Notifications table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: varchar("title").notNull(),
  message: text("message").notNull(),
  type: varchar("type").notNull(), // job_alert, message, connection, application_update
  relatedId: integer("related_id"), // related job, message, etc.
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_notifications_user_id").on(table.userId),
  index("idx_notifications_is_read").on(table.isRead),
  index("idx_notifications_created_at").on(table.createdAt),
]);

// Enhanced Employer groups table
export const employerGroups = pgTable("employer_groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  employerId: varchar("employer_id").notNull().references(() => users.id),
  isPrivate: boolean("is_private").default(false),
  memberCount: integer("member_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_employer_groups_employer_id").on(table.employerId),
]);

// Group members table
export const groupMembers = pgTable("group_members", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull().references(() => employerGroups.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  role: varchar("role").default("member"), // member, moderator
  joinedAt: timestamp("joined_at").defaultNow(),
}, (table) => [
  index("idx_group_members_group_id").on(table.groupId),
  index("idx_group_members_user_id").on(table.userId),
]);

// Enhanced Training modules table
export const trainingModules = pgTable("training_modules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  content: text("content"),
  videoUrl: text("video_url"),
  documentUrl: text("document_url"),
  duration: integer("duration"), // in minutes
  difficulty: varchar("difficulty").default("beginner"), // beginner, intermediate, advanced
  groupId: integer("group_id").notNull().references(() => employerGroups.id),
  createdById: varchar("created_by_id").notNull().references(() => users.id),
  isActive: boolean("is_active").default(true),
  completionCount: integer("completion_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_training_modules_group_id").on(table.groupId),
  index("idx_training_modules_created_by_id").on(table.createdById),
]);

// Training progress table
export const trainingProgress = pgTable("training_progress", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  moduleId: integer("module_id").notNull().references(() => trainingModules.id),
  status: varchar("status").default("not_started"), // not_started, in_progress, completed
  progressPercentage: integer("progress_percentage").default(0),
  completedAt: timestamp("completed_at"),
  timeSpent: integer("time_spent").default(0), // in minutes
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_training_progress_user_id").on(table.userId),
  index("idx_training_progress_module_id").on(table.moduleId),
]);

// Enhanced Job applications table
export const jobApplications = pgTable("job_applications", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").notNull().references(() => jobPostings.id),
  applicantId: varchar("applicant_id").notNull().references(() => users.id),
  status: varchar("status").default("pending"), // pending, reviewed, interview, hired, rejected
  coverLetter: text("cover_letter"),
  resumeUrl: text("resume_url"),
  portfolioVideoId: integer("portfolio_video_id").references(() => videoPortfolios.id),
  notes: text("notes"), // employer notes
  interviewScheduledAt: timestamp("interview_scheduled_at"),
  appliedAt: timestamp("applied_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_job_applications_job_id").on(table.jobId),
  index("idx_job_applications_applicant_id").on(table.applicantId),
  index("idx_job_applications_status").on(table.status),
]);

// Enhanced Member connections table
export const memberConnections = pgTable("member_connections", {
  id: serial("id").primaryKey(),
  requesterId: varchar("requester_id").notNull().references(() => users.id),
  receiverId: varchar("receiver_id").notNull().references(() => users.id),
  status: varchar("status").default("pending"), // pending, accepted, declined, blocked
  message: text("message"), // connection request message
  connectedAt: timestamp("connected_at"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_member_connections_requester_id").on(table.requesterId),
  index("idx_member_connections_receiver_id").on(table.receiverId),
  index("idx_member_connections_status").on(table.status),
]);

// Enhanced Job alerts table
export const jobAlerts = pgTable("job_alerts", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: varchar("title").notNull(),
  keywords: text("keywords").array(),
  tradeCategory: varchar("trade_category"),
  location: varchar("location"),
  salaryMin: integer("salary_min"),
  experienceLevel: varchar("experience_level"),
  employmentType: varchar("employment_type"),
  isActive: boolean("is_active").default(true),
  frequency: varchar("frequency").default("daily"), // immediate, daily, weekly
  lastTriggered: timestamp("last_triggered"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("idx_job_alerts_user_id").on(table.userId),
  index("idx_job_alerts_is_active").on(table.isActive),
]);

// User reviews and ratings table
export const userReviews = pgTable("user_reviews", {
  id: serial("id").primaryKey(),
  reviewerId: varchar("reviewer_id").notNull().references(() => users.id),
  revieweeId: varchar("reviewee_id").notNull().references(() => users.id),
  rating: integer("rating").notNull(), // 1-5 stars
  review: text("review"),
  jobId: integer("job_id").references(() => jobPostings.id), // optional job context
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_user_reviews_reviewer_id").on(table.reviewerId),
  index("idx_user_reviews_reviewee_id").on(table.revieweeId),
]);

// Analytics table for tracking user interactions
export const userAnalytics = pgTable("user_analytics", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  actionType: varchar("action_type").notNull(), // login, job_view, video_view, profile_view, etc.
  resourceType: varchar("resource_type"), // job, video, user, etc.
  resourceId: varchar("resource_id"), // id of the resource
  metadata: jsonb("metadata"), // additional data
  ipAddress: varchar("ip_address"),
  userAgent: text("user_agent"),
  timestamp: timestamp("timestamp").defaultNow(),
}, (table) => [
  index("idx_user_analytics_user_id").on(table.userId),
  index("idx_user_analytics_action_type").on(table.actionType),
  index("idx_user_analytics_timestamp").on(table.timestamp),
]);

// Platform analytics table
export const platformAnalytics = pgTable("platform_analytics", {
  id: serial("id").primaryKey(),
  metric: varchar("metric").notNull(), // active_users, job_postings_created, videos_uploaded, etc.
  value: integer("value").notNull(),
  date: timestamp("date").notNull(),
  metadata: jsonb("metadata"),
}, (table) => [
  index("idx_platform_analytics_metric").on(table.metric),
  index("idx_platform_analytics_date").on(table.date),
]);

// Saved jobs table
export const savedJobs = pgTable("saved_jobs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  jobId: integer("job_id").notNull().references(() => jobPostings.id),
  notes: text("notes"),
  savedAt: timestamp("saved_at").defaultNow(),
}, (table) => [
  index("idx_saved_jobs_user_id").on(table.userId),
  index("idx_saved_jobs_job_id").on(table.jobId),
]);

// Video likes table
export const videoLikes = pgTable("video_likes", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  videoId: integer("video_id").notNull().references(() => videoPortfolios.id),
  likedAt: timestamp("liked_at").defaultNow(),
}, (table) => [
  index("idx_video_likes_user_id").on(table.userId),
  index("idx_video_likes_video_id").on(table.videoId),
]);

// Video comments table
export const videoComments = pgTable("video_comments", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").notNull().references(() => videoPortfolios.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  comment: text("comment").notNull(),
  parentCommentId: integer("parent_comment_id"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("idx_video_comments_video_id").on(table.videoId),
  index("idx_video_comments_user_id").on(table.userId),
]);

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  jobPostings: many(jobPostings),
  videoPortfolios: many(videoPortfolios),
  jobApplications: many(jobApplications),
  employerGroups: many(employerGroups),
  groupMemberships: many(groupMembers),
  trainingModules: many(trainingModules),
  memberConnectionsRequester: many(memberConnections, { relationName: "requester" }),
  memberConnectionsReceiver: many(memberConnections, { relationName: "receiver" }),
  jobAlerts: many(jobAlerts),
  sentMessages: many(messages, { relationName: "sender" }),
  receivedMessages: many(messages, { relationName: "receiver" }),
  notifications: many(notifications),
  reviewsGiven: many(userReviews, { relationName: "reviewer" }),
  reviewsReceived: many(userReviews, { relationName: "reviewee" }),
  analytics: many(userAnalytics),
  savedJobs: many(savedJobs),
  videoLikes: many(videoLikes),
  videoComments: many(videoComments),
  trainingProgress: many(trainingProgress),
}));

export const jobPostingsRelations = relations(jobPostings, ({ one, many }) => ({
  postedBy: one(users, {
    fields: [jobPostings.postedBy],
    references: [users.id],
  }),
  applications: many(jobApplications),
  savedBy: many(savedJobs),
}));

export const videoPortfoliosRelations = relations(videoPortfolios, ({ one, many }) => ({
  user: one(users, {
    fields: [videoPortfolios.userId],
    references: [users.id],
  }),
  likes: many(videoLikes),
  comments: many(videoComments),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  sender: one(users, {
    fields: [messages.senderId],
    references: [users.id],
    relationName: "sender",
  }),
  receiver: one(users, {
    fields: [messages.receiverId],
    references: [users.id],
    relationName: "receiver",
  }),
  relatedJob: one(jobPostings, {
    fields: [messages.relatedJobId],
    references: [jobPostings.id],
  }),
}));

export const employerGroupsRelations = relations(employerGroups, ({ one, many }) => ({
  employer: one(users, {
    fields: [employerGroups.employerId],
    references: [users.id],
  }),
  members: many(groupMembers),
  trainingModules: many(trainingModules),
}));

export const groupMembersRelations = relations(groupMembers, ({ one }) => ({
  group: one(employerGroups, {
    fields: [groupMembers.groupId],
    references: [employerGroups.id],
  }),
  user: one(users, {
    fields: [groupMembers.userId],
    references: [users.id],
  }),
}));

export const trainingModulesRelations = relations(trainingModules, ({ one, many }) => ({
  group: one(employerGroups, {
    fields: [trainingModules.groupId],
    references: [employerGroups.id],
  }),
  createdBy: one(users, {
    fields: [trainingModules.createdById],
    references: [users.id],
  }),
  progress: many(trainingProgress),
}));

export const trainingProgressRelations = relations(trainingProgress, ({ one }) => ({
  user: one(users, {
    fields: [trainingProgress.userId],
    references: [users.id],
  }),
  module: one(trainingModules, {
    fields: [trainingProgress.moduleId],
    references: [trainingModules.id],
  }),
}));

export const jobApplicationsRelations = relations(jobApplications, ({ one }) => ({
  job: one(jobPostings, {
    fields: [jobApplications.jobId],
    references: [jobPostings.id],
  }),
  applicant: one(users, {
    fields: [jobApplications.applicantId],
    references: [users.id],
  }),
  portfolioVideo: one(videoPortfolios, {
    fields: [jobApplications.portfolioVideoId],
    references: [videoPortfolios.id],
  }),
}));

export const memberConnectionsRelations = relations(memberConnections, ({ one }) => ({
  requester: one(users, {
    fields: [memberConnections.requesterId],
    references: [users.id],
    relationName: "requester",
  }),
  receiver: one(users, {
    fields: [memberConnections.receiverId],
    references: [users.id],
    relationName: "receiver",
  }),
}));

export const jobAlertsRelations = relations(jobAlerts, ({ one }) => ({
  user: one(users, {
    fields: [jobAlerts.userId],
    references: [users.id],
  }),
}));

// Zod schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertJobPostingSchema = createInsertSchema(jobPostings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertVideoPortfolioSchema = createInsertSchema(videoPortfolios).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

export const insertEmployerGroupSchema = createInsertSchema(employerGroups).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTrainingModuleSchema = createInsertSchema(trainingModules).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertJobApplicationSchema = createInsertSchema(jobApplications).omit({
  id: true,
  appliedAt: true,
  updatedAt: true,
});

export const insertMemberConnectionSchema = createInsertSchema(memberConnections).omit({
  id: true,
  createdAt: true,
});

export const insertJobAlertSchema = createInsertSchema(jobAlerts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export const insertUserReviewSchema = createInsertSchema(userReviews).omit({
  id: true,
  createdAt: true,
});

// Type exports
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertJobPosting = z.infer<typeof insertJobPostingSchema>;
export type JobPosting = typeof jobPostings.$inferSelect;
export type InsertVideoPortfolio = z.infer<typeof insertVideoPortfolioSchema>;
export type VideoPortfolio = typeof videoPortfolios.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertEmployerGroup = z.infer<typeof insertEmployerGroupSchema>;
export type EmployerGroup = typeof employerGroups.$inferSelect;
export type InsertTrainingModule = z.infer<typeof insertTrainingModuleSchema>;
export type TrainingModule = typeof trainingModules.$inferSelect;
export type InsertJobApplication = z.infer<typeof insertJobApplicationSchema>;
export type JobApplication = typeof jobApplications.$inferSelect;
export type InsertMemberConnection = z.infer<typeof insertMemberConnectionSchema>;
export type MemberConnection = typeof memberConnections.$inferSelect;
export type InsertJobAlert = z.infer<typeof insertJobAlertSchema>;
export type JobAlert = typeof jobAlerts.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertUserReview = z.infer<typeof insertUserReviewSchema>;
export type UserReview = typeof userReviews.$inferSelect;
export type TrainingProgress = typeof trainingProgress.$inferSelect;
export type UserAnalytics = typeof userAnalytics.$inferSelect;
export type SavedJob = typeof savedJobs.$inferSelect;
export type VideoLike = typeof videoLikes.$inferSelect;
export type VideoComment = typeof videoComments.$inferSelect;